/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        display: ["Syne", "sans-serif"],
        sans: ["Rajdhani", "sans-serif"],
        mono: ["IBM Plex Mono", "monospace"],
      },
      colors: {
        ink: {
          950: "#05070b",
          900: "#070b12",
          800: "#0b1220",
          700: "#101827",
          600: "#162033",
        },
        cyan: {
          glow: "#00e5ff",
        },
      },
      boxShadow: {
        glow: "0 0 24px rgba(0,229,255,0.18)",
        panel: "0 12px 40px rgba(0,0,0,0.45)",
      },
    },
  },
  plugins: [],
};
