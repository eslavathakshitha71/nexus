import { useStore } from "../lib/store";
import { api } from "../lib/api";

export default function Events() {
  const twin = useStore((s) => s.twin);
  const events = twin?.events || [];
  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div className="flex justify-between items-end">
        <div>
          <div className="kicker">Event intelligence</div>
          <h1 className="font-display text-2xl">Campus events</h1>
        </div>
        <button
          onClick={() => api.trigger("start_event")}
          className="px-3 py-1.5 border border-cyan-400/40 text-cyan-200 text-xs uppercase tracking-widest"
        >
          Start TECHNOVA
        </button>
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        {events.map((e: any) => {
          const occ = Math.min(100, (e.current / Math.max(e.capacity, 1)) * 100);
          return (
            <div key={e.id} className="panel p-5">
              <div className="flex justify-between">
                <div>
                  <div className="kicker">{e.status} · {e.venue}</div>
                  <div className="font-display text-2xl">{e.name}</div>
                </div>
                <div className={`kicker ${e.risk === "HIGH" || e.risk === "CRITICAL" ? "text-rose-300" : "text-amber-300"}`}>
                  AI RISK {e.risk}
                </div>
              </div>
              <p className="text-sm text-slate-400 mt-2">{e.description}</p>
              <div className="grid grid-cols-4 gap-2 mt-4">
                <Stat k="Expected" v={e.expected} />
                <Stat k="Current" v={e.current} />
                <Stat k="Pred. peak" v={e.predicted_peak} />
                <Stat k="Capacity" v={e.capacity} />
              </div>
              <div className="h-2 bg-white/5 mt-4">
                <div className="h-full bg-cyan-400" style={{ width: `${occ}%` }} />
              </div>
              <div className="text-[11px] text-slate-500 mt-1">{occ.toFixed(0)}% occupancy · growth {e.growth}</div>
              {e.predicted_peak > e.capacity && (
                <div className="mt-3 text-sm text-rose-300">
                  Predicted peak exceeds venue capacity. Open overflow and cap walk-ins.
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
function Stat({ k, v }: any) {
  return (
    <div className="bg-black/30 p-2">
      <div className="kicker">{k}</div>
      <div className="num text-lg">{v}</div>
    </div>
  );
}
