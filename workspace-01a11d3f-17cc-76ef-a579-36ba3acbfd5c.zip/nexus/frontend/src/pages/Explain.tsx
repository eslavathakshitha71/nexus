import { useState } from "react";
import { api } from "../lib/api";

export default function Explain() {
  const [rep, setRep] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  async function gen() {
    setBusy(true);
    try {
      setRep(await api.explain());
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div className="flex justify-between items-end">
        <div>
          <div className="kicker">End-of-day intelligence</div>
          <h1 className="font-display text-2xl">Explain my campus</h1>
        </div>
        <button
          onClick={gen}
          className="px-4 py-2 border border-cyan-300 text-cyan-100 text-xs uppercase tracking-widest"
        >
          {busy ? "Generating…" : "Generate briefing"}
        </button>
      </div>
      {!rep && (
        <div className="panel p-10 text-center text-slate-400">
          Produce an AI-written campus intelligence report from the live twin and today’s telemetry.
        </div>
      )}
      {rep && (
        <div className="panel p-6 max-w-3xl">
          <div className="kicker">{rep.generated_at}</div>
          <h2 className="font-display text-3xl mt-1">{rep.title}</h2>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-3 mt-6">
            <Stat k="Peak pop" v={rep.peak_population} />
            <Stat k="Peak crowd" v={rep.peak_crowd_zone} />
            <Stat k="Aud peak" v={rep.peak_auditorium} />
            <Stat k="Parking peak" v={`${rep.parking_peak}%`} />
            <Stat k="Anomalies" v={rep.major_anomalies} />
            <Stat k="Events" v={rep.major_events} />
          </div>
          <p className="mt-6 text-lg leading-relaxed text-slate-200">{rep.summary}</p>
          <div className="mt-6">
            <div className="kicker mb-2">Why the risk score</div>
            <ul className="text-sm text-slate-300 space-y-1">
              {(rep.risk?.reasons || []).map((r: string, i: number) => (
                <li key={i}>• {r}</li>
              ))}
            </ul>
            <div className="text-cyan-200 text-sm mt-2">{rep.risk?.recommended_action}</div>
          </div>
          <div className="mt-6">
            <div className="kicker mb-2">Timeline</div>
            <div className="space-y-2">
              {(rep.timeline || []).map((t: any, i: number) => (
                <div key={i} className="flex gap-3 text-sm">
                  <div className="font-mono text-cyan-300 w-16">{t.t}</div>
                  <div className="text-slate-300">{t.text}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-6 text-[11px] text-slate-500">{rep.privacy_note}</div>
        </div>
      )}
    </div>
  );
}
function Stat({ k, v }: any) {
  return (
    <div className="bg-black/30 p-2">
      <div className="kicker">{k}</div>
      <div className="num">{v}</div>
    </div>
  );
}
