import { useStore } from "../lib/store";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export default function Predictions() {
  const twin = useStore((s) => s.twin);
  const preds = twin?.predictions || [];
  const hist = (twin ? [] : []) as any[];
  // synthesize a short curve from current vs predicted
  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <Header title="Predictive campus intelligence" kicker="Current → predicted → recommended action" />
      <div className="grid md:grid-cols-3 gap-3">
        {preds.map((p: any) => (
          <div key={p.kind} className="panel p-4">
            <div className="kicker">{p.kind}</div>
            <div className="font-display text-xl mt-1">{p.target}</div>
            <div className="mt-4 flex items-center gap-3">
              <Col label="Current" v={fmt(p.current, p.kind)} />
              <div className="text-cyan-500">→</div>
              <Col label={`+${p.horizon_min}m`} v={fmt(p.predicted, p.kind)} accent />
            </div>
            <div className="mt-3 h-16">
              <ResponsiveContainer>
                <AreaChart data={spark(p)}>
                  <defs>
                    <linearGradient id={"g" + p.kind} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#00e5ff" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="#00e5ff" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Area type="monotone" dataKey="v" stroke="#00e5ff" fill={`url(#g${p.kind})`} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 text-xs text-slate-400">
              Confidence {(p.confidence * 100).toFixed(0)}%
              {p.mins_to_capacity != null && ` · capacity in ~${p.mins_to_capacity} min`}
            </div>
            <div className="mt-2 text-sm text-cyan-100">{p.recommendation}</div>
          </div>
        ))}
      </div>

      <div className="panel p-4">
        <div className="kicker mb-3">Why these forecasts</div>
        <ul className="text-sm text-slate-300 space-y-1">
          {(twin?.risk?.reasons || []).map((r: string, i: number) => (
            <li key={i}>• {r}</li>
          ))}
        </ul>
        <div className="mt-3 text-sm text-cyan-200">{twin?.risk?.recommended_action}</div>
      </div>
    </div>
  );
}

function Header({ title, kicker }: any) {
  return (
    <div>
      <div className="kicker">{kicker}</div>
      <h1 className="font-display text-2xl">{title}</h1>
    </div>
  );
}
function Col({ label, v, accent }: any) {
  return (
    <div>
      <div className="kicker">{label}</div>
      <div className={`num text-2xl ${accent ? "text-cyan-300" : "text-white"}`}>{v}</div>
    </div>
  );
}
function fmt(v: number, kind: string) {
  if (kind === "PARKING") return `${v}%`;
  return Math.round(v).toLocaleString();
}
function spark(p: any) {
  const a = Number(p.current) || 0;
  const b = Number(p.predicted) || a;
  return [0, 1, 2, 3, 4].map((i) => ({ t: i, v: a + ((b - a) * i) / 4 }));
}
