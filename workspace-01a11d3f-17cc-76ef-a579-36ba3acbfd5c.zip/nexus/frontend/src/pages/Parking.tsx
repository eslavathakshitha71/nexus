import { useStore } from "../lib/store";

export default function Parking() {
  const twin = useStore((s) => s.twin);
  const parks = Object.values(twin?.parking || {}) as any[];
  const pred = (twin?.predictions || []).find((p: any) => p.kind === "PARKING");
  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div>
        <div className="kicker">Smart parking intelligence</div>
        <h1 className="font-display text-2xl">Parking twin</h1>
      </div>
      {pred && (
        <div className="panel p-4 text-sm">
          <span className="text-amber-300">AI · </span>
          {pred.recommendation}
        </div>
      )}
      <div className="grid md:grid-cols-2 gap-3">
        {parks.map((p) => (
          <div key={p.code} className="panel p-4">
            <div className="flex justify-between">
              <div>
                <div className="kicker">{p.category}</div>
                <div className="font-display text-xl">{p.name}</div>
              </div>
              <div className={`num text-3xl ${p.occupancy > 90 ? "text-rose-400" : p.occupancy > 75 ? "text-amber-300" : "text-emerald-300"}`}>
                {p.occupancy}%
              </div>
            </div>
            <div className="h-2 bg-white/5 mt-3">
              <div className="h-full bg-cyan-400" style={{ width: `${p.occupancy}%` }} />
            </div>
            <div className="grid grid-cols-4 gap-2 mt-3 text-sm">
              <Stat k="Occupied" v={p.occupied} />
              <Stat k="Available" v={p.available} />
              <Stat k="Cars" v={p.cars} />
              <Stat k="Bikes" v={p.bikes} />
            </div>
            <div className="text-[11px] text-slate-500 mt-2">
              Growth {p.growth_per_10m}/10min · typical envelope {p.typical_range?.[0]}–{p.typical_range?.[1]} occupied
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
function Stat({ k, v }: any) {
  return (
    <div className="bg-black/30 p-2">
      <div className="kicker">{k}</div>
      <div className="num">{v}</div>
    </div>
  );
}
