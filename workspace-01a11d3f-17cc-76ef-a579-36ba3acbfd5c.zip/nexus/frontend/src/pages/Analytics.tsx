import { useEffect, useState } from "react";
import { api } from "../lib/api";
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export default function Analytics() {
  const [range, setRange] = useState("7d");
  const [data, setData] = useState<any>(null);
  useEffect(() => {
    api.analytics(range).then(setData);
  }, [range]);
  const series = (data?.series || []).map((d: any, i: number) => ({
    ...d,
    i,
    label: (d.t || "").slice(5, 16),
  }));
  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div className="flex justify-between items-end">
        <div>
          <div className="kicker">Trends · anomalies · prediction accuracy</div>
          <h1 className="font-display text-2xl">Analytics</h1>
        </div>
        <div className="flex gap-1">
          {["today", "7d", "30d"].map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`px-3 py-1 text-xs uppercase border ${range === r ? "border-cyan-300 text-cyan-200" : "border-white/10 text-slate-400"}`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>
      <div className="panel p-4 h-80">
        <ResponsiveContainer>
          <LineChart data={series}>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" />
            <XAxis dataKey="label" stroke="#64748b" fontSize={10} minTickGap={24} />
            <YAxis stroke="#64748b" fontSize={11} />
            <Tooltip contentStyle={{ background: "#0b1220", border: "1px solid #164e63" }} />
            <Legend />
            <Line type="monotone" dataKey="population" stroke="#00e5ff" dot={false} name="Population" />
            <Line type="monotone" dataKey="parking" stroke="#ffb020" dot={false} name="Parking %" />
            <Line type="monotone" dataKey="risk" stroke="#ff3d5a" dot={false} name="Risk" />
            <Line type="monotone" dataKey="traffic" stroke="#8b7cff" dot={false} name="Traffic" />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="grid md:grid-cols-4 gap-3">
        {Object.entries(data?.accuracy || {}).map(([k, v]: any) => (
          <div key={k} className="panel p-4">
            <div className="kicker">{k} model</div>
            <div className="num text-2xl text-cyan-100">{Math.round(v * 100)}%</div>
            <div className="text-[11px] text-slate-500">rolling accuracy vs later observed</div>
          </div>
        ))}
      </div>
    </div>
  );
}
