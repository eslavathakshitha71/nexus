import { useEffect, useState } from "react";
import { useStore } from "../lib/store";
import { api } from "../lib/api";

export default function Cameras() {
  const twin = useStore((s) => s.twin);
  const cams = twin?.cameras || [];
  const [job, setJob] = useState<any>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setTick((x) => x + 1), 2500);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (!job?.id || job.status === "DONE" || job.status === "ERROR") return;
    api.visionJob(job.id).then(setJob).catch(() => {});
  }, [tick]);

  async function onFile(f: File | undefined, cameraId: string) {
    if (!f) return;
    const r = await api.uploadVision(f, cameraId);
    setJob({ id: r.job_id, status: "RUNNING" });
  }

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div>
        <div className="kicker">Anonymous computer vision · no facial recognition</div>
        <h1 className="font-display text-2xl">Camera management</h1>
      </div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
        {cams.map((c: any) => (
          <div key={c.camera_id} className="panel overflow-hidden">
            <div className="relative aspect-video bg-black">
              <img
                src={`/api/cameras/${c.camera_id}/frame?t=${tick}`}
                alt={c.camera_id}
                className="w-full h-full object-cover opacity-90"
              />
              <div className="absolute top-2 left-2 kicker bg-black/50 px-2 py-0.5">
                {c.camera_id} · {c.status}
              </div>
            </div>
            <div className="p-3 text-sm">
              <div className="flex justify-between">
                <div>
                  <div className="font-medium">{c.name}</div>
                  <div className="text-slate-500 text-xs">{c.location}</div>
                </div>
                <div className="text-right font-mono text-xs text-cyan-200">
                  {c.fps?.toFixed?.(1)} FPS
                  <div className="text-slate-500">AI {c.ai_status}</div>
                </div>
              </div>
              <div className="flex gap-3 mt-2 text-xs text-slate-400">
                <span>People {c.people}</span>
                <span>Vehicles {c.vehicles}</span>
                <span>{c.source_type}</span>
              </div>
              <label className="mt-2 block text-[11px] text-cyan-300 cursor-pointer">
                Upload clip for this camera
                <input
                  type="file"
                  accept="video/*"
                  className="hidden"
                  onChange={(e) => onFile(e.target.files?.[0], c.camera_id)}
                />
              </label>
            </div>
          </div>
        ))}
      </div>
      {job && (
        <div className="panel p-4 text-sm">
          <div className="kicker">Vision job {job.id || ""}</div>
          <div>
            Status {job.status} · frames {job.frames} · people avg {job.people_avg} · vehicles avg {job.vehicles_avg} ·{" "}
            {job.density}
          </div>
          {job.preview && (
            <img src={`/api/vision/preview/${job.preview}`} className="mt-2 max-w-lg border border-white/10" />
          )}
          {job.error && <div className="text-rose-400">{job.error}</div>}
        </div>
      )}
    </div>
  );
}
