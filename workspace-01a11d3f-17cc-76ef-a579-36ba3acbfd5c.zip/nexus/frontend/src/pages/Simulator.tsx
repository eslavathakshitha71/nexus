import { useEffect, useState } from "react";
import { api } from "../lib/api";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export default function Simulator() {
  const [scenarios, setScenarios] = useState<any[]>([]);
  const [sid, setSid] = useState("gate_closed");
  const [params, setParams] = useState<Record<string, any>>({ gate: "main_gate" });
  const [result, setResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.scenarios().then((r) => setScenarios(r.scenarios));
  }, []);

  const sc = scenarios.find((s) => s.id === sid);

  async function run() {
    setBusy(true);
    try {
      const r = await api.runSim(sid, params);
      setResult(r);
    } finally {
      setBusy(false);
    }
  }

  const chart = result
    ? [
        { k: "Population", current: result.comparison.population[0], simulated: result.comparison.population[1] },
        { k: "Risk", current: result.comparison.risk[0], simulated: result.comparison.risk[1] },
        { k: "Parking %", current: result.comparison.parking[0], simulated: result.comparison.parking[1] },
        { k: "Auditorium", current: result.comparison.auditorium[0], simulated: result.comparison.auditorium[1] },
        { k: "Main Gate", current: result.comparison.main_gate_in[0], simulated: result.comparison.east_gate_in ? result.comparison.main_gate_in[1] : 0 },
        { k: "East Gate", current: result.comparison.east_gate_in[0], simulated: result.comparison.east_gate_in[1] },
      ]
    : [];

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div>
        <div className="kicker">Signature feature</div>
        <h1 className="font-display text-2xl">What-If Simulator</h1>
        <p className="text-slate-400 text-sm mt-1">
          Ask “what happens if…?” The twin clones current reality and projects 15 / 30 / 60 minutes forward.
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-3">
        <div className="panel p-4 space-y-3">
          <div className="kicker">Scenario</div>
          <select
            value={sid}
            onChange={(e) => {
              setSid(e.target.value);
              setResult(null);
            }}
            className="w-full bg-black/40 border border-cyan-400/20 px-3 py-2"
          >
            {scenarios.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
          <div className="text-sm text-slate-300 italic">“{sc?.prompt}”</div>
          {(sc?.params || []).map((p: any) => (
            <label key={p.key} className="block">
              <div className="kicker mb-1">{p.label}</div>
              {p.type === "select" ? (
                <select
                  className="w-full bg-black/40 border border-white/10 px-2 py-1.5"
                  value={params[p.key] ?? p.default}
                  onChange={(e) => setParams({ ...params, [p.key]: e.target.value })}
                >
                  {p.options.map((o: string) => (
                    <option key={o}>{o}</option>
                  ))}
                </select>
              ) : (
                <input
                  type="number"
                  className="w-full bg-black/40 border border-white/10 px-2 py-1.5"
                  defaultValue={p.default}
                  onChange={(e) => setParams({ ...params, [p.key]: Number(e.target.value) })}
                />
              )}
            </label>
          ))}
          <button
            onClick={run}
            disabled={busy}
            className="w-full py-2 bg-cyan-400/20 border border-cyan-300 text-cyan-100 uppercase tracking-widest text-sm"
          >
            {busy ? "Simulating…" : "Run simulation"}
          </button>
        </div>

        <div className="lg:col-span-2 panel p-4">
          <div className="kicker mb-2">Current reality vs simulated future (T+30m)</div>
          {result ? (
            <div className="h-64">
              <ResponsiveContainer>
                <BarChart data={chart}>
                  <CartesianGrid stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="k" stroke="#64748b" fontSize={11} />
                  <YAxis stroke="#64748b" fontSize={11} />
                  <Tooltip contentStyle={{ background: "#0b1220", border: "1px solid #164e63" }} />
                  <Legend />
                  <Bar dataKey="current" fill="#64748b" name="Current reality" />
                  <Bar dataKey="simulated" fill="#00e5ff" name="Simulated future" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-64 grid place-items-center text-slate-500 text-sm">
              Run a scenario to compare reality against the simulated future.
            </div>
          )}
        </div>
      </div>

      {result && (
        <>
          <div className="grid md:grid-cols-3 gap-3">
            {["t15", "t30", "t60"].map((k) => (
              <div key={k} className="panel p-4">
                <div className="kicker">{k.replace("t", "T+") } minutes</div>
                <div className="num text-3xl text-cyan-100 mt-1">{result[k].risk.score}</div>
                <div className="text-xs text-slate-400">Risk · {result[k].risk.level}</div>
                <div className="mt-2 text-sm text-slate-300">
                  Population {result[k].population?.toLocaleString()} · Auditorium{" "}
                  {result[k].zones.auditorium.people} ({result[k].zones.auditorium.density})
                </div>
              </div>
            ))}
          </div>
          <div className="grid md:grid-cols-2 gap-3">
            <div className="panel p-4">
              <div className="kicker mb-2">Impacts</div>
              <div className="max-h-64 overflow-y-auto text-sm space-y-1">
                {result.impacts.map((i: any, idx: number) => (
                  <div key={idx} className="flex justify-between border-b border-white/5 py-1">
                    <span className="text-slate-400">{i.label}</span>
                    <span className="num">
                      {i.from} → <span className={i.delta > 0 ? "text-amber-300" : "text-emerald-300"}>{i.to}</span>
                      <span className="text-slate-500"> {i.unit}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <div className="panel p-4">
              <div className="kicker mb-2">AI recommendation</div>
              <p className="text-sm text-cyan-100 mb-3">{result.narrative}</p>
              <ul className="text-sm text-slate-300 space-y-1">
                {result.recommendations.map((r: string, i: number) => (
                  <li key={i}>• {r}</li>
                ))}
              </ul>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
