import { useStore } from "../lib/store";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";

export default function Crowd() {
  const twin = useStore((s) => s.twin);
  const zones = Object.values(twin?.zones || {}) as any[];
  const total = zones.reduce((a, z) => a + (z.people || 0), 0);
  const growth = zones.reduce((a, z) => a + Math.max(z.growth_rate || 0, 0), 0) / Math.max(zones.length, 1);
  const pred = Math.round(total + growth * 12);
  const data = zones
    .filter((z) => z.kind !== "parking")
    .sort((a, b) => b.people - a.people)
    .slice(0, 12)
    .map((z) => ({ name: z.name.replace("Parking Zone ", "P-"), people: z.people, cap: z.capacity }));

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div>
        <div className="kicker">Anonymous crowd intelligence</div>
        <h1 className="font-display text-2xl">Crowd analysis</h1>
      </div>
      <div className="grid md:grid-cols-4 gap-3">
        <Card k="Current crowd" v={total.toLocaleString()} />
        <Card k="Growth rate" v={`+${growth.toFixed(1)} / tick`} />
        <Card k="Est. in 20 min" v={pred.toLocaleString()} />
        <Card k="Class" v={total > 8000 ? "HIGH" : total > 4500 ? "MEDIUM" : "LOW"} />
      </div>
      <div className="panel p-4 h-80">
        <ResponsiveContainer>
          <BarChart data={data}>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" />
            <XAxis dataKey="name" stroke="#64748b" fontSize={10} interval={0} angle={-25} textAnchor="end" height={70} />
            <YAxis stroke="#64748b" />
            <Tooltip contentStyle={{ background: "#0b1220", border: "1px solid #164e63" }} />
            <Bar dataKey="people" fill="#00e5ff" />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="panel p-4 text-sm text-cyan-100">
        High crowd concentration likely within 20 minutes at{" "}
        {zones.sort((a, b) => b.people - a.people)[0]?.name || "—"}. No identity tracking is used — counts only.
      </div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
        {zones.map((z) => (
          <div key={z.code} className="panel p-3">
            <div className="flex justify-between">
              <div className="font-medium">{z.name}</div>
              <div className="kicker">{z.density}</div>
            </div>
            <div className="num text-2xl text-cyan-100">{z.people}</div>
            <div className="h-1.5 bg-white/5 mt-2">
              <div
                className="h-full bg-cyan-400"
                style={{ width: `${Math.min(100, (z.people / Math.max(z.capacity, 1)) * 100)}%` }}
              />
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {z.direction} · growth {z.growth_rate} · cap {z.capacity}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
function Card({ k, v }: any) {
  return (
    <div className="panel p-4">
      <div className="kicker">{k}</div>
      <div className="num text-2xl text-cyan-100 mt-1">{v}</div>
    </div>
  );
}
