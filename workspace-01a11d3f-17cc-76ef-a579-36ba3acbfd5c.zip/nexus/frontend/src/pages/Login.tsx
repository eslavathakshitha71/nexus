import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { Cpu } from "lucide-react";
import { api, setToken } from "../lib/api";
import { useStore } from "../lib/store";

const ACCOUNTS = [
  { role: "Super Admin", user: "superadmin", pass: "Nexus@2026" },
  { role: "Campus Admin", user: "campusadmin", pass: "Campus@2026" },
  { role: "Security", user: "security", pass: "Secure@2026" },
  { role: "Event Admin", user: "eventadmin", pass: "Event@2026" },
];

export default function Login() {
  const nav = useNavigate();
  const setUser = useStore((s) => s.setUser);
  const [username, setUsername] = useState("campusadmin");
  const [password, setPassword] = useState("Campus@2026");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    try {
      const r = await api.login(username, password);
      setToken(r.token);
      setUser(r.user);
      nav("/");
    } catch (ex: any) {
      setErr(ex.message || "Login failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="h-full relative overflow-hidden flex">
      <div className="flex-1 hidden md:flex flex-col justify-between p-12 relative">
        <div className="absolute inset-0 opacity-40">
          <svg viewBox="0 0 800 800" className="w-full h-full">
            <defs>
              <pattern id="g" width="32" height="32" patternUnits="userSpaceOnUse">
                <path d="M32 0 H0 V32" fill="none" stroke="rgba(0,229,255,0.12)" />
              </pattern>
            </defs>
            <rect width="800" height="800" fill="url(#g)" />
            <rect x="120" y="180" width="140" height="90" fill="none" stroke="#00e5ff" opacity="0.5" />
            <rect x="300" y="200" width="200" height="140" fill="none" stroke="#00e5ff" opacity="0.7" />
            <rect x="540" y="160" width="120" height="80" fill="none" stroke="#ffb020" opacity="0.6" />
            <path d="M80 420 H720" stroke="#00e5ff" strokeDasharray="6 8" opacity="0.4" />
          </svg>
        </div>
        <div className="relative">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 border border-cyan-400/50 grid place-items-center">
              <Cpu className="text-cyan-300" />
            </div>
            <div className="logo-type text-2xl text-cyan-100">NEXUS</div>
          </div>
          <div className="kicker mt-3">AI Digital Twin for Campus Intelligence</div>
        </div>
        <div className="relative max-w-xl">
          <h1 className="font-display text-4xl md:text-5xl leading-tight text-white">
            Understand the present.
            <br />
            Simulate the future.
            <br />
            <span className="text-cyan-300">Prevent the unexpected.</span>
          </h1>
          <p className="mt-6 text-slate-400 max-w-md">
            A continuously updated digital twin of campus movement, crowd, parking, events, weather and
            resources — with anomaly detection, prediction and what-if simulation. Anonymous by design.
          </p>
        </div>
        <div className="relative kicker text-slate-500">NIT-HYD · COMMAND CENTER · DEMO MODE</div>
      </div>

      <div className="w-full md:w-[420px] bg-[#070b12]/90 border-l border-cyan-400/15 p-10 flex flex-col justify-center">
        <div className="kicker mb-2">Operator access</div>
        <h2 className="font-display text-2xl mb-6">Sign in to the twin</h2>
        <form onSubmit={submit} className="space-y-4">
          <label className="block">
            <div className="kicker mb-1">Username</div>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-black/40 border border-cyan-400/20 px-3 py-2 outline-none focus:border-cyan-300"
            />
          </label>
          <label className="block">
            <div className="kicker mb-1">Password</div>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-black/40 border border-cyan-400/20 px-3 py-2 outline-none focus:border-cyan-300"
            />
          </label>
          {err && <div className="text-rose-400 text-sm">{err}</div>}
          <button
            disabled={busy}
            className="w-full py-2.5 bg-cyan-400/20 border border-cyan-300 text-cyan-100 uppercase tracking-[0.25em] text-sm hover:bg-cyan-400/30"
          >
            {busy ? "Authenticating…" : "Enter command center"}
          </button>
        </form>
        <div className="mt-8">
          <div className="kicker mb-2">Demo roles</div>
          <div className="space-y-1">
            {ACCOUNTS.map((a) => (
              <button
                key={a.user}
                onClick={() => {
                  setUsername(a.user);
                  setPassword(a.pass);
                }}
                className="w-full text-left px-3 py-2 text-xs border border-white/5 hover:border-cyan-400/30 flex justify-between"
              >
                <span className="text-slate-300">{a.role}</span>
                <span className="font-mono text-slate-500">
                  {a.user} / {a.pass}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
