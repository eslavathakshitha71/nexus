import { useState } from "react";
import { useNavigate } from "react-router-dom";
import DigitalTwin from "../components/DigitalTwin";
import { useStore } from "../lib/store";
import { api } from "../lib/api";

const DEMOS = [
  { name: "demo_sequence", label: "Run live demo", hint: "Event → crowd → parking → traffic → risk" },
  { name: "start_event", label: "Start TECHNOVA", hint: "Event goes live" },
  { name: "crowd_increase", label: "Crowd surge", hint: "Plaza concentration" },
  { name: "parking_shortage", label: "Parking pressure", hint: "Fill Zone A" },
  { name: "vehicle_increase", label: "Vehicle inflow", hint: "Gate traffic up" },
  { name: "gate_closure", label: "Close Main Gate", hint: "Redistribute flow" },
  { name: "weather_change", label: "Heavy rain", hint: "Outdoor disruption" },
  { name: "resource_anomaly", label: "Power anomaly", hint: "Grid +28%" },
  { name: "restricted_activity", label: "Restricted zone", hint: "Lab perimeter" },
  { name: "reset", label: "Reset twin", hint: "Return to nominal" },
];

export default function Dashboard() {
  const twin = useStore((s) => s.twin);
  const nav = useNavigate();
  const [busy, setBusy] = useState("");
  const risk = twin?.risk || {};
  const alerts = (twin?.alerts || []).filter((a: any) => a.status === "OPEN").slice(0, 6);
  const preds = twin?.predictions || [];
  const env = twin?.environment || {};

  async function fire(name: string) {
    setBusy(name);
    try {
      await api.trigger(name, name === "gate_closure" ? { gate: "main_gate" } : {});
    } finally {
      setBusy("");
    }
  }

  const level = (risk.level || "NORMAL").toLowerCase();

  return (
    <div className="h-full grid grid-cols-12 gap-3 p-3">
      <div className="col-span-12 xl:col-span-8 panel overflow-hidden flex flex-col">
        <div className="px-4 py-2 flex items-center justify-between border-b border-white/5">
          <div>
            <div className="kicker">Interactive campus digital twin</div>
            <div className="text-sm text-slate-300">
              Heatmaps · crowd · traffic flow · parking · events · cameras
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="inline-flex items-center gap-1 text-emerald-300">
              <i className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> AI {twin?.ai_engine?.status || "…"}
            </span>
            <span className="text-slate-500 font-mono">tick {twin?.tick ?? 0}</span>
            <span className="text-slate-500 uppercase">{twin?.mode}</span>
          </div>
        </div>
        <div className="flex-1 min-h-0">
          <DigitalTwin />
        </div>
      </div>

      <div className="col-span-12 xl:col-span-4 flex flex-col gap-3 min-h-0 overflow-hidden">
        <div className="panel p-4">
          <div className="kicker">Campus status</div>
          <div className="flex items-end justify-between mt-1">
            <div className={`font-display text-3xl ${
              level === "critical" ? "text-rose-400" :
              level === "elevated" ? "text-orange-400" :
              level === "moderate" ? "text-amber-300" : "text-emerald-300"
            }`}>
              {risk.level || "—"}
            </div>
            <div className="num text-2xl text-cyan-100">
              {risk.score ?? "—"}<span className="text-xs text-slate-500">/100</span>
            </div>
          </div>
          <div className="mt-3 space-y-1">
            {(risk.contributors || []).slice(0, 5).map((c: any) => (
              <div key={c.key} className="flex items-center gap-2 text-[12px]">
                <div className="w-28 text-slate-400 truncate">{c.key}</div>
                <div className="flex-1 h-1.5 bg-white/5">
                  <div className="h-full bg-cyan-400/70" style={{ width: `${Math.min(100, c.value * 4)}%` }} />
                </div>
                <div className="num w-10 text-right text-cyan-200">+{c.value}</div>
              </div>
            ))}
          </div>
          <div className="mt-3 text-xs text-slate-400 leading-relaxed">
            {(risk.reasons || []).slice(0, 3).map((r: string, i: number) => (
              <div key={i}>• {r}</div>
            ))}
          </div>
          <div className="mt-2 text-xs text-cyan-200">{risk.recommended_action}</div>
        </div>

        <div className="panel p-3 flex-1 min-h-0 overflow-y-auto">
          <div className="flex justify-between items-center mb-2">
            <div className="kicker">Smart alerts</div>
            <button className="text-[10px] text-cyan-300" onClick={() => nav("/alerts")}>
              VIEW ALL
            </button>
          </div>
          <div className="space-y-2">
            {alerts.length === 0 && <div className="text-slate-500 text-sm">No open alerts.</div>}
            {alerts.map((a: any) => (
              <div key={a.id} className="border border-white/5 p-2 bg-black/20">
                <div className="flex justify-between text-[11px]">
                  <span className={a.severity === "HIGH" || a.severity === "CRITICAL" ? "text-rose-300" : "text-amber-300"}>
                    {a.alert_type}
                  </span>
                  <span className="text-slate-500">{a.location}</span>
                </div>
                <div className="text-xs text-slate-300 mt-1">{a.reason}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="panel p-3">
          <div className="kicker mb-2">Now → next</div>
          <div className="space-y-2">
            {preds.slice(0, 3).map((p: any) => (
              <div key={p.kind} className="text-xs flex justify-between gap-2">
                <span className="text-slate-400">{p.target}</span>
                <span className="num text-slate-200">
                  {p.current} → <span className="text-cyan-300">{p.predicted}</span>
                </span>
              </div>
            ))}
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            {env.condition} · {env.temperature_c}°C · AQI {env.aqi}
          </div>
        </div>
      </div>

      <div className="col-span-12 panel p-3">
        <div className="flex items-center justify-between mb-2">
          <div>
            <div className="kicker">Demo control — no hardware required</div>
            <div className="text-xs text-slate-400">
              Drive the hackathon sequence from here. Twin, alerts, risk and predictions update live.
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => nav("/simulator")} className="text-[11px] px-3 py-1 border border-cyan-400/30 text-cyan-200">
              OPEN WHAT-IF
            </button>
            <button onClick={() => nav("/explain")} className="text-[11px] px-3 py-1 border border-white/15 text-slate-300">
              EXPLAIN MY CAMPUS
            </button>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {DEMOS.map((d) => (
            <button
              key={d.name}
              onClick={() => fire(d.name)}
              disabled={busy === d.name}
              className={`px-3 py-2 border text-left min-w-[140px] ${
                d.name === "demo_sequence"
                  ? "border-cyan-300 bg-cyan-400/10 text-cyan-100"
                  : d.name === "reset"
                  ? "border-white/10 text-slate-400"
                  : "border-white/10 hover:border-cyan-400/40"
              }`}
            >
              <div className="text-xs uppercase tracking-wide">{busy === d.name ? "Firing…" : d.label}</div>
              <div className="text-[10px] text-slate-500">{d.hint}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
