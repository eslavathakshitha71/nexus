import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { useStore } from "../lib/store";

export default function Settings() {
  const user = useStore((s) => s.user);
  const [p, setP] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  useEffect(() => {
    api.privacy().then(setP);
    api.users().then((r) => setUsers(r.users)).catch(() => {});
  }, []);
  async function save(patch: any) {
    const next = await api.setPrivacy(patch);
    setP(next);
  }
  if (!p) return null;
  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div>
        <div className="kicker">Privacy-first by default</div>
        <h1 className="font-display text-2xl">Privacy & access</h1>
      </div>
      <div className="panel p-5 space-y-3 max-w-2xl">
        <Toggle
          label="Anonymous analytics only"
          hint="Count, density, flow, vehicles, environment. No names."
          on={p.anonymous_analytics_only}
          set={(v) => save({ anonymous_analytics_only: v })}
        />
        <Toggle
          label="Facial recognition"
          hint="Kept OFF. NEXUS is not an identification system."
          on={p.facial_recognition}
          set={(v) => save({ facial_recognition: v })}
        />
        <Toggle
          label="Identity tracking"
          hint="Do not follow individual students across cameras."
          on={p.identity_tracking}
          set={(v) => save({ identity_tracking: v })}
        />
        <Toggle
          label="Store raw video"
          hint="Demo default is off — keep derived counts only."
          on={p.store_raw_video}
          set={(v) => save({ store_raw_video: v })}
        />
        <Toggle
          label="Audit logging"
          hint="Record operator actions on the twin."
          on={p.audit_logging}
          set={(v) => save({ audit_logging: v })}
        />
        <label className="block">
          <div className="kicker mb-1">Data retention (days)</div>
          <input
            type="number"
            defaultValue={p.data_retention_days}
            className="bg-black/40 border border-white/10 px-3 py-1.5 w-32"
            onBlur={(e) => save({ data_retention_days: Number(e.target.value) })}
          />
        </label>
      </div>
      <div className="panel p-5 max-w-2xl">
        <div className="kicker">Signed in</div>
        <div className="text-lg">
          {user?.full_name} · {user?.role}
        </div>
        <div className="text-slate-500 text-sm">{user?.email}</div>
      </div>
      {users.length > 0 && (
        <div className="panel p-5 max-w-2xl">
          <div className="kicker mb-2">Operators</div>
          {users.map((u) => (
            <div key={u.id} className="flex justify-between text-sm py-1 border-b border-white/5">
              <span>
                {u.full_name} <span className="text-slate-500">@{u.username}</span>
              </span>
              <span className="text-cyan-300">{u.role}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
function Toggle({ label, hint, on, set }: any) {
  return (
    <button onClick={() => set(!on)} className="w-full text-left flex justify-between gap-4 py-2 border-b border-white/5">
      <div>
        <div>{label}</div>
        <div className="text-xs text-slate-500">{hint}</div>
      </div>
      <div className={`w-10 h-5 rounded-full relative ${on ? "bg-cyan-400/60" : "bg-white/10"}`}>
        <i className={`absolute top-0.5 h-4 w-4 bg-white rounded-full transition ${on ? "left-5" : "left-0.5"}`} />
      </div>
    </button>
  );
}
