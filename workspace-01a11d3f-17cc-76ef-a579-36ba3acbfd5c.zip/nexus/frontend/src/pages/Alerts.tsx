import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { useStore } from "../lib/store";

export default function Alerts() {
  const twin = useStore((s) => s.twin);
  const [hist, setHist] = useState<any[]>([]);
  useEffect(() => {
    api.alerts().then((r) => setHist(r.history || []));
  }, [twin?.alerts?.length]);

  const live = twin?.alerts || [];

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div>
        <div className="kicker">Smart alert system</div>
        <h1 className="font-display text-2xl">Alerts</h1>
      </div>
      <div className="space-y-2">
        {live.map((a: any) => (
          <div key={a.id} className="panel p-4">
            <div className="flex flex-wrap justify-between gap-2">
              <div>
                <div className={`kicker ${sev(a.severity)}`}>{a.severity} · {a.alert_type}</div>
                <div className="font-display text-lg">{a.location}</div>
              </div>
              <div className="text-xs text-slate-500 font-mono">{a.time?.slice(11, 19)} · {a.status}</div>
            </div>
            <div className="mt-2 text-sm text-slate-300">{a.reason}</div>
            {a.prediction && <div className="text-sm text-amber-200 mt-1">Prediction: {a.prediction}</div>}
            <div className="text-sm text-cyan-200 mt-1">Action: {a.recommended_action}</div>
            {a.status === "OPEN" && (
              <button
                className="mt-2 text-[11px] uppercase tracking-widest text-slate-400"
                onClick={() => api.patchAlert(a.id, "ACK")}
              >
                Acknowledge
              </button>
            )}
          </div>
        ))}
        {live.length === 0 && <div className="text-slate-500">No live alerts.</div>}
      </div>
      <div>
        <div className="kicker mb-2">History</div>
        <div className="panel divide-y divide-white/5">
          {hist.slice(0, 20).map((a) => (
            <div key={a.id} className="px-4 py-2 text-sm flex justify-between">
              <span>
                {a.alert_type} · {a.location}
              </span>
              <span className="text-slate-500">{a.severity}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
function sev(s: string) {
  if (s === "CRITICAL" || s === "HIGH") return "text-rose-300";
  if (s === "MEDIUM") return "text-amber-300";
  return "text-emerald-300";
}
