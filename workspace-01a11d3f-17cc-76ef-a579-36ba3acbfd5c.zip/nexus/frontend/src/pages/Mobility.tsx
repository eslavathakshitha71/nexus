import { useStore } from "../lib/store";
import DigitalTwin from "../components/DigitalTwin";

export default function Mobility() {
  const twin = useStore((s) => s.twin);
  const routes = twin?.mobility || [];
  return (
    <div className="h-full grid lg:grid-cols-2 gap-3 p-3">
      <div className="panel overflow-hidden">
        <div className="px-4 py-2 border-b border-white/5">
          <div className="kicker">Movement heatmap</div>
        </div>
        <DigitalTwin />
      </div>
      <div className="panel p-4 overflow-y-auto">
        <div className="kicker mb-3">Corridor intelligence</div>
        <div className="space-y-2">
          {routes.map((r: any) => (
            <div key={r.code} className="border border-white/5 p-3">
              <div className="flex justify-between">
                <div className="font-medium">{r.name}</div>
                <div className="kicker">{r.congestion}</div>
              </div>
              <div className="h-1.5 bg-white/5 mt-2">
                <div className="h-full bg-cyan-400" style={{ width: `${Math.min(100, (r.volume / 160) * 100)}%` }} />
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Volume {r.volume} · {r.direction} {r.peak ? "· PEAK" : ""}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
