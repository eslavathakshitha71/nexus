import { useEffect, useState } from "react";
import { api } from "../lib/api";

export default function Replay() {
  const [window, setWindow] = useState("today");
  const [data, setData] = useState<any>(null);
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    api.replay(window).then((r) => {
      setData(r);
      setIdx(0);
    });
  }, [window]);
  const frames = data?.live?.length ? data.live : data?.history || [];
  const f = frames[idx];
  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div className="flex justify-between items-end">
        <div>
          <div className="kicker">Historical replay</div>
          <h1 className="font-display text-2xl">How the campus evolved</h1>
        </div>
        <div className="flex gap-1">
          {["today", "yesterday", "week"].map((w) => (
            <button
              key={w}
              onClick={() => setWindow(w)}
              className={`px-3 py-1 text-xs uppercase border ${window === w ? "border-cyan-300 text-cyan-200" : "border-white/10"}`}
            >
              {w}
            </button>
          ))}
        </div>
      </div>
      {f && (
        <div className="panel p-6">
          <div className="kicker">{(f.t || "").replace("T", " ").slice(0, 19)}</div>
          <div className="font-display text-2xl mt-1">{f.label}</div>
          <div className="grid md:grid-cols-5 gap-3 mt-4">
            <Stat k="Population" v={f.population} />
            <Stat k="Risk" v={f.risk} />
            <Stat k="Parking" v={`${f.parking}%`} />
            <Stat k="Auditorium" v={f.auditorium ?? "—"} />
            <Stat k="Main Gate in" v={f.main_gate_in ?? "—"} />
          </div>
        </div>
      )}
      <input
        type="range"
        min={0}
        max={Math.max(0, frames.length - 1)}
        value={idx}
        onChange={(e) => setIdx(Number(e.target.value))}
        className="w-full"
      />
      <div className="panel divide-y divide-white/5 max-h-80 overflow-y-auto">
        {frames.map((fr: any, i: number) => (
          <button
            key={i}
            onClick={() => setIdx(i)}
            className={`w-full text-left px-4 py-2 text-sm ${i === idx ? "bg-cyan-400/10" : ""}`}
          >
            <span className="font-mono text-cyan-300 mr-3">{(fr.t || "").slice(11, 19)}</span>
            {fr.label}
          </button>
        ))}
      </div>
    </div>
  );
}
function Stat({ k, v }: any) {
  return (
    <div className="bg-black/30 p-3">
      <div className="kicker">{k}</div>
      <div className="num text-xl">{v}</div>
    </div>
  );
}
