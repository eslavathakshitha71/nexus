import { useStore } from "../lib/store";

export default function Resources() {
  const twin = useStore((s) => s.twin);
  const res = twin?.resources || {};
  const env = twin?.environment || {};
  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <div>
        <div className="kicker">Campus-level resources · not classrooms</div>
        <h1 className="font-display text-2xl">Resources & environment</h1>
      </div>
      <div className="grid md:grid-cols-3 gap-3">
        {Object.entries(res).map(([k, r]: any) => (
          <div key={k} className="panel p-4">
            <div className="flex justify-between">
              <div className="kicker">{r.name}</div>
              <div className={r.status === "ANOMALY" ? "text-rose-300 kicker" : "text-emerald-300 kicker"}>
                {r.status}
              </div>
            </div>
            <div className="num text-3xl text-cyan-100 mt-2">
              {r.value} <span className="text-xs text-slate-500">{r.unit}</span>
            </div>
            <div className="text-xs text-slate-500 mt-1">Baseline {r.baseline}</div>
            {r.status === "ANOMALY" && (
              <div className="text-sm text-amber-200 mt-2">
                Consumption anomaly detected. Possible explanation: large event + extended operating hours.
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="panel p-5">
        <div className="kicker">Environment intelligence</div>
        <div className="grid md:grid-cols-6 gap-3 mt-3">
          <Stat k="Condition" v={env.condition} />
          <Stat k="Temp" v={`${env.temperature_c}°C`} />
          <Stat k="Humidity" v={`${env.humidity}%`} />
          <Stat k="Rain" v={`${env.rain_mm} mm`} />
          <Stat k="AQI" v={env.aqi} />
          <Stat k="Wind" v={`${env.wind_kmh} km/h`} />
        </div>
        <p className="text-sm text-slate-400 mt-4">{env.forecast}</p>
        {env.rain_mm >= 8 && (
          <div className="mt-3 text-amber-200 text-sm">
            ⚠ Event disruption risk — heavy rain vs outdoor occupancy. Consider moving overflow indoors.
          </div>
        )}
      </div>
    </div>
  );
}
function Stat({ k, v }: any) {
  return (
    <div className="bg-black/30 p-3">
      <div className="kicker">{k}</div>
      <div className="num text-lg">{v ?? "—"}</div>
    </div>
  );
}
