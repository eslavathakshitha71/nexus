import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { useEffect, useRef, type ReactNode } from "react";
import { api, connectTwinSocket, getToken } from "./lib/api";
import { useStore } from "./lib/store";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Predictions from "./pages/Predictions";
import Simulator from "./pages/Simulator";
import Events from "./pages/Events";
import Parking from "./pages/Parking";
import Crowd from "./pages/Crowd";
import Cameras from "./pages/Cameras";
import Alerts from "./pages/Alerts";
import Analytics from "./pages/Analytics";
import Resources from "./pages/Resources";
import Replay from "./pages/Replay";
import Explain from "./pages/Explain";
import Mobility from "./pages/Mobility";
import Settings from "./pages/Settings";

function Guard({ children }: { children: ReactNode }) {
  const token = getToken();
  const loc = useLocation();
  if (!token) return <Navigate to="/login" state={{ from: loc }} replace />;
  return <>{children}</>;
}

export default function App() {
  const setTwin = useStore((s) => s.setTwin);
  const setUser = useStore((s) => s.setUser);
  const user = useStore((s) => s.user);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!getToken()) return;
    api.me().then(setUser).catch(() => {});
    api.twin().then(setTwin).catch(() => {});
    const ws = connectTwinSocket(setTwin);
    wsRef.current = ws;
    const poll = setInterval(() => {
      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
        api.twin().then(setTwin).catch(() => {});
      }
    }, 2500);
    return () => {
      clearInterval(poll);
      ws.close();
    };
  }, [setTwin, setUser, user?.username]);

  return (
    <>
      <div className="scanlines" />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/"
          element={
            <Guard>
              <Layout />
            </Guard>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="predictions" element={<Predictions />} />
          <Route path="simulator" element={<Simulator />} />
          <Route path="events" element={<Events />} />
          <Route path="parking" element={<Parking />} />
          <Route path="crowd" element={<Crowd />} />
          <Route path="cameras" element={<Cameras />} />
          <Route path="alerts" element={<Alerts />} />
          <Route path="analytics" element={<Analytics />} />
          <Route path="resources" element={<Resources />} />
          <Route path="replay" element={<Replay />} />
          <Route path="explain" element={<Explain />} />
          <Route path="mobility" element={<Mobility />} />
          <Route path="settings" element={<Settings />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}
