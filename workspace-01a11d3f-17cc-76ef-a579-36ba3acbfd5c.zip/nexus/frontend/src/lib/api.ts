const TOKEN_KEY = "nexus_token";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY) || "";
}
export function setToken(t: string) {
  localStorage.setItem(TOKEN_KEY, t);
}
export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function req(path: string, opts: RequestInit = {}) {
  const headers: Record<string, string> = {
    ...(opts.headers as Record<string, string>),
  };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (opts.body && !(opts.body instanceof FormData) && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }
  const res = await fetch(path, { ...opts, headers });
  if (res.status === 401) {
    clearToken();
    if (!path.includes("/auth/login")) window.location.href = "/login";
  }
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const j = await res.json();
      detail = j.detail || JSON.stringify(j);
    } catch {}
    throw new Error(detail);
  }
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) return res.json();
  return res;
}

export const api = {
  login: (username: string, password: string) =>
    req("/api/auth/login", { method: "POST", body: JSON.stringify({ username, password }) }),
  me: () => req("/api/auth/me"),
  twin: () => req("/api/twin"),
  cameras: () => req("/api/cameras"),
  crowd: () => req("/api/crowd"),
  parking: () => req("/api/parking"),
  events: () => req("/api/events"),
  traffic: () => req("/api/traffic"),
  resources: () => req("/api/resources"),
  environment: () => req("/api/environment"),
  mobility: () => req("/api/mobility"),
  alerts: () => req("/api/alerts"),
  patchAlert: (id: number, status: string) =>
    req(`/api/alerts/${id}`, { method: "POST", body: JSON.stringify({ status }) }),
  predictions: () => req("/api/predictions"),
  risk: () => req("/api/risk"),
  scenarios: () => req("/api/simulations/scenarios"),
  runSim: (scenario: string, params: Record<string, any> = {}) =>
    req("/api/simulations/run", { method: "POST", body: JSON.stringify({ scenario, params }) }),
  simulations: () => req("/api/simulations"),
  ask: (question: string) =>
    req("/api/assistant/ask", { method: "POST", body: JSON.stringify({ question }) }),
  explain: () => req("/api/explain"),
  trigger: (name: string, params: Record<string, any> = {}) =>
    req("/api/demo/trigger", { method: "POST", body: JSON.stringify({ name, params }) }),
  analytics: (range = "7d") => req(`/api/analytics?range=${range}`),
  replay: (window = "today") => req(`/api/replay?window=${window}`),
  privacy: () => req("/api/privacy"),
  setPrivacy: (body: any) => req("/api/privacy", { method: "POST", body: JSON.stringify(body) }),
  users: () => req("/api/users"),
  uploadVision: async (file: File, cameraId = "UPLOAD") => {
    const fd = new FormData();
    fd.append("file", file);
    return req(`/api/vision/upload?camera_id=${cameraId}`, { method: "POST", body: fd });
  },
  visionJob: (id: string) => req(`/api/vision/jobs/${id}`),
};

export function connectTwinSocket(onMsg: (data: any) => void) {
  const proto = window.location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${window.location.host}/ws`);
  ws.onmessage = (ev) => {
    try {
      onMsg(JSON.parse(ev.data));
    } catch {}
  };
  return ws;
}
