import { create } from "zustand";

type User = { username: string; full_name: string; email: string; role: string } | null;

type Store = {
  user: User;
  setUser: (u: User) => void;
  twin: any;
  setTwin: (t: any) => void;
  assistantOpen: boolean;
  setAssistantOpen: (v: boolean) => void;
  selectedZone: string | null;
  setSelectedZone: (z: string | null) => void;
};

export const useStore = create<Store>((set) => ({
  user: null,
  setUser: (user) => set({ user }),
  twin: null,
  setTwin: (twin) => set({ twin }),
  assistantOpen: false,
  setAssistantOpen: (assistantOpen) => set({ assistantOpen }),
  selectedZone: null,
  setSelectedZone: (selectedZone) => set({ selectedZone }),
}));
