import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  Activity,
  AlertTriangle,
  Brain,
  Camera,
  Car,
  CloudSun,
  Cpu,
  GitBranch,
  LayoutDashboard,
  Map,
  MessageSquare,
  ParkingCircle,
  Radio,
  Settings as SettingsIcon,
  Shield,
  Sparkles,
  Users,
  Waypoints,
} from "lucide-react";
import { useStore } from "../lib/store";
import { clearToken } from "../lib/api";
import Assistant from "./Assistant";

const NAV = [
  { to: "/", label: "Command", icon: LayoutDashboard },
  { to: "/predictions", label: "Predictions", icon: Activity },
  { to: "/simulator", label: "What-If", icon: GitBranch },
  { to: "/crowd", label: "Crowd", icon: Users },
  { to: "/parking", label: "Parking", icon: ParkingCircle },
  { to: "/events", label: "Events", icon: Sparkles },
  { to: "/mobility", label: "Mobility", icon: Waypoints },
  { to: "/cameras", label: "Cameras", icon: Camera },
  { to: "/alerts", label: "Alerts", icon: AlertTriangle },
  { to: "/resources", label: "Resources", icon: CloudSun },
  { to: "/analytics", label: "Analytics", icon: Radio },
  { to: "/replay", label: "Replay", icon: Map },
  { to: "/explain", label: "Explain", icon: Brain },
  { to: "/settings", label: "Privacy", icon: SettingsIcon },
];

function riskClass(level?: string) {
  const l = (level || "NORMAL").toLowerCase();
  if (l === "critical") return "risk-critical";
  if (l === "elevated") return "risk-elevated";
  if (l === "moderate") return "risk-moderate";
  return "risk-normal";
}

export default function Layout() {
  const twin = useStore((s) => s.twin);
  const user = useStore((s) => s.user);
  const setAssistantOpen = useStore((s) => s.setAssistantOpen);
  const nav = useNavigate();
  const kpis = twin?.kpis || {};
  const risk = twin?.risk || {};
  const clock = new Date().toLocaleString("en-IN", { hour12: false });

  return (
    <div className="h-full flex text-slate-100">
      <aside className="w-[220px] shrink-0 border-r border-cyan-400/10 bg-[#070b12]/90 flex flex-col">
        <div className="px-5 pt-6 pb-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-sm border border-cyan-400/50 grid place-items-center shadow-glow">
              <Cpu size={16} className="text-cyan-300" />
            </div>
            <div>
              <div className="logo-type text-[15px] text-cyan-200 leading-none">NEXUS</div>
              <div className="kicker mt-1" style={{ letterSpacing: "0.28em", fontSize: 8 }}>
                CAMPUS TWIN
              </div>
            </div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-2 pb-4 space-y-0.5">
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.to === "/"}
              className={({ isActive }) =>
                `flex items-center gap-2.5 px-3 py-2 rounded-sm text-[13px] tracking-wide uppercase font-medium transition ${
                  isActive
                    ? "bg-cyan-400/10 text-cyan-200 border-l-2 border-cyan-300"
                    : "text-slate-400 hover:text-cyan-100 hover:bg-white/5"
                }`
              }
            >
              <n.icon size={15} />
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t border-white/5 text-[11px] text-slate-500">
          <div className="flex items-center gap-2 text-slate-300">
            <Shield size={12} className="text-cyan-400" />
            Anon analytics
          </div>
          <div className="mt-1 font-mono text-[10px] text-slate-500">NO IDENTITY TRACKING</div>
        </div>
      </aside>

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-14 shrink-0 border-b border-cyan-400/10 bg-[#070b12]/80 backdrop-blur flex items-center px-5 gap-4">
          <div className="flex-1 min-w-0">
            <div className="logo-type text-[11px] text-slate-400 tracking-[0.35em]">
              AI DIGITAL TWIN FOR CAMPUS INTELLIGENCE
            </div>
            <div className="text-[12px] text-slate-500 truncate">
              {twin?.headline || "Synchronizing twin…"}
            </div>
          </div>
          <Kpi label="Population" value={kpis.population?.toLocaleString?.() || "—"} />
          <Kpi label="Cameras" value={`${kpis.active_cameras ?? "—"}/${kpis.total_cameras ?? "—"}`} />
          <Kpi label="Events" value={kpis.active_events ?? "—"} />
          <Kpi label="Parking" value={kpis.parking_occupancy != null ? `${kpis.parking_occupancy}%` : "—"} />
          <div className="px-3 py-1 panel">
            <div className="kicker">Risk</div>
            <div className={`num text-lg leading-none ${riskClass(risk.level)}`}>
              {risk.score ?? "—"}
              <span className="text-[10px] ml-1 text-slate-400">/100</span>
            </div>
          </div>
          <button
            onClick={() => setAssistantOpen(true)}
            className="flex items-center gap-2 px-3 py-1.5 border border-cyan-400/30 text-cyan-200 text-xs uppercase tracking-widest hover:bg-cyan-400/10"
          >
            <MessageSquare size={14} /> Ask NEXUS
          </button>
          <div className="text-right">
            <div className="num text-[11px] text-cyan-200">{clock}</div>
            <button
              className="text-[11px] text-slate-400 hover:text-white"
              onClick={() => {
                clearToken();
                nav("/login");
              }}
            >
              {user?.full_name || "Operator"} · Sign out
            </button>
          </div>
        </header>
        <main className="flex-1 min-h-0 overflow-hidden">
          <Outlet />
        </main>
      </div>
      <Assistant />
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: any }) {
  return (
    <div className="hidden xl:block px-2">
      <div className="kicker">{label}</div>
      <div className="num text-sm text-cyan-100">{value}</div>
    </div>
  );
}
