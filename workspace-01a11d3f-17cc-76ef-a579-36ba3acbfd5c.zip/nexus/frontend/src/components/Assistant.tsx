import { useState } from "react";
import { X, Send, Sparkles } from "lucide-react";
import { useStore } from "../lib/store";
import { api } from "../lib/api";

const SUGGESTIONS = [
  "How is the campus right now?",
  "Where is the highest crowd concentration?",
  "Which parking zone will fill first?",
  "Is any unusual activity happening?",
  "What could happen if Gate 1 is closed?",
  "What is today's biggest operational risk?",
  "Why is the campus risk score high?",
  "What events may create congestion?",
];

export default function Assistant() {
  const open = useStore((s) => s.assistantOpen);
  const setOpen = useStore((s) => s.setAssistantOpen);
  const [q, setQ] = useState("");
  const [msgs, setMsgs] = useState<{ role: string; text: string; title?: string }[]>([
    {
      role: "ai",
      title: "NEXUS Decision Assistant",
      text: "I read the live digital twin — anonymous counts, flows, parking, weather and risk. Ask me anything an operator would ask.",
    },
  ]);
  const [busy, setBusy] = useState(false);

  async function ask(question: string) {
    const query = question.trim();
    if (!query) return;
    setMsgs((m) => [...m, { role: "user", text: query }]);
    setQ("");
    setBusy(true);
    try {
      const r = await api.ask(query);
      setMsgs((m) => [...m, { role: "ai", title: r.title, text: r.answer }]);
    } catch (e: any) {
      setMsgs((m) => [...m, { role: "ai", text: e.message || "Assistant unavailable" }]);
    } finally {
      setBusy(false);
    }
  }

  if (!open) return null;
  return (
    <div className="fixed inset-y-0 right-0 w-full max-w-md z-[60] bg-[#070b12]/95 border-l border-cyan-400/20 flex flex-col shadow-panel">
      <div className="h-14 px-4 flex items-center justify-between border-b border-white/10">
        <div className="flex items-center gap-2 text-cyan-200">
          <Sparkles size={16} />
          <span className="logo-type text-sm tracking-[0.2em]">NEXUS AI</span>
        </div>
        <button onClick={() => setOpen(false)}>
          <X size={16} className="text-slate-400" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {msgs.map((m, i) => (
          <div
            key={i}
            className={`p-3 text-sm leading-relaxed ${
              m.role === "user"
                ? "bg-cyan-400/10 border border-cyan-400/20 ml-8"
                : "bg-white/5 border border-white/10 mr-4"
            }`}
          >
            {m.title && <div className="kicker mb-1">{m.title}</div>}
            <div className="whitespace-pre-wrap text-slate-200">{m.text}</div>
          </div>
        ))}
        {busy && <div className="kicker">Fusing twin state…</div>}
      </div>
      <div className="px-4 pb-2 flex flex-wrap gap-1">
        {SUGGESTIONS.slice(0, 4).map((s) => (
          <button
            key={s}
            onClick={() => ask(s)}
            className="text-[10px] uppercase tracking-wide px-2 py-1 border border-white/10 text-slate-400 hover:text-cyan-200"
          >
            {s}
          </button>
        ))}
      </div>
      <form
        className="p-3 border-t border-white/10 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          ask(q);
        }}
      >
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Ask the twin…"
          className="flex-1 bg-black/40 border border-cyan-400/20 px-3 py-2 text-sm outline-none focus:border-cyan-300"
        />
        <button className="px-3 border border-cyan-400/40 text-cyan-200">
          <Send size={14} />
        </button>
      </form>
    </div>
  );
}
