import { useStore } from "../lib/store";

const DENSITY_CLASS: Record<string, string> = {
  LOW: "heatmap-low",
  MEDIUM: "heatmap-medium",
  HIGH: "heatmap-high",
  CRITICAL: "heatmap-critical",
};

export default function DigitalTwin({ height = 640 }: { height?: number }) {
  const twin = useStore((s) => s.twin);
  const selected = useStore((s) => s.selectedZone);
  const setSelected = useStore((s) => s.setSelectedZone);
  const zones = twin?.zones || {};
  const parking = twin?.parking || {};
  const gates = twin?.gates || {};
  const alerts = twin?.alerts || [];

  const z = (code: string) => zones[code] || {};
  const p = (code: string) => parking[code] || {};
  const g = (code: string) => gates[code] || {};

  const hot = new Set(
    alerts.filter((a: any) => a.status === "OPEN" && a.severity !== "LOW").map((a: any) => a.location)
  );

  return (
    <div className="relative w-full h-full min-h-[420px]">
      <svg viewBox="0 0 1000 700" className="w-full h-full" preserveAspectRatio="xMidYMid meet">
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(0,229,255,0.05)" strokeWidth="1" />
          </pattern>
          <radialGradient id="glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgba(0,229,255,0.18)" />
            <stop offset="100%" stopColor="rgba(0,229,255,0)" />
          </radialGradient>
          <filter id="soft">
            <feGaussianBlur stdDeviation="2.5" />
          </filter>
        </defs>
        <rect width="1000" height="700" fill="#070b12" />
        <rect width="1000" height="700" fill="url(#grid)" />
        <rect x="20" y="20" width="960" height="660" fill="none" stroke="rgba(0,229,255,0.18)" strokeWidth="1" />
        <text x="36" y="48" fill="#5ee7ff" fontFamily="IBM Plex Mono" fontSize="11" letterSpacing="3">
          NEXUS INSTITUTE OF TECHNOLOGY  ·  HYDERABAD  ·  LIVE TWIN
        </text>
        <text x="36" y="66" fill="#64748b" fontFamily="IBM Plex Mono" fontSize="9">
          ANONYMOUS DENSITY · NO FACIAL RECOGNITION
        </text>

        {/* Roads */}
        <path d="M80 640 L920 640 L920 60 L80 60 Z" fill="none" stroke="rgba(148,163,184,0.12)" strokeWidth="18" />
        <path
          d="M500 60 L500 640 M80 360 L920 360 M80 500 L920 500"
          fill="none"
          stroke="rgba(0,229,255,0.18)"
          strokeWidth="10"
          strokeLinecap="round"
        />
        <path
          d="M500 60 L500 640 M80 360 L920 360"
          fill="none"
          stroke="rgba(0,229,255,0.55)"
          strokeWidth="1.5"
          className="flow-line"
        />

        <Building
          z={z("library")}
          x={70} y={120} w={150} h={110}
          selected={selected}
          onSelect={setSelected}
        />
        <Building
          z={z("admin")}
          x={250} y={130} w={120} h={80}
          selected={selected}
          onSelect={setSelected}
        />
        <Building
          z={z("academic_a")}
          x={70} y={270} w={160} h={100}
          selected={selected}
          onSelect={setSelected}
        />
        <Building
          z={z("academic_b")}
          x={70} y={400} w={160} h={100}
          selected={selected}
          onSelect={setSelected}
        />
        <Building
          z={z("hostel")}
          x={70} y={540} w={170} h={70}
          selected={selected}
          onSelect={setSelected}
        />
        <Building
          z={z("plaza")}
          x={300} y={280} w={220} h={140}
          selected={selected}
          onSelect={setSelected}
          round={18}
        />
        <Building
          z={z("auditorium")}
          x={560} y={120} w={170} h={120}
          selected={selected}
          onSelect={setSelected}
        />
        <Building
          z={z("cafeteria")}
          x={560} y={280} w={150} h={90}
          selected={selected}
          onSelect={setSelected}
        />
        <Building
          z={z("lawn")}
          x={560} y={400} w={180} h={90}
          selected={selected}
          onSelect={setSelected}
          round={20}
        />
        <Building
          z={z("sports")}
          x={780} y={80} w={150} h={110}
          selected={selected}
          onSelect={setSelected}
        />
        <Building
          z={z("restricted")}
          x={780} y={210} w={130} h={70}
          selected={selected}
          onSelect={setSelected}
          restricted
        />
        <Building
          z={z("parking_a")}
          x={780} y={300} w={140} h={80}
          selected={selected}
          onSelect={setSelected}
          parking={p("parking_a")}
        />
        <Building
          z={z("parking_b")}
          x={780} y={400} w={140} h={70}
          selected={selected}
          onSelect={setSelected}
          parking={p("parking_b")}
        />
        <Building
          z={z("parking_c")}
          x={560} y={530} w={150} h={70}
          selected={selected}
          onSelect={setSelected}
          parking={p("parking_c")}
        />
        <Building
          z={z("parking_2w")}
          x={400} y={540} w={130} h={50}
          selected={selected}
          onSelect={setSelected}
          parking={p("parking_2w")}
        />
        <Building
          z={z("transport")}
          x={270} y={540} w={120} h={60}
          selected={selected}
          onSelect={setSelected}
        />

        <Gate x={430} y={620} w={140} h={42} g={g("main_gate")} label="MAIN GATE" onSelect={() => setSelected("main_gate")} />
        <Gate x={430} y={28} w={140} h={36} g={g("north_gate")} label="NORTH GATE" onSelect={() => setSelected("north_gate")} />
        <Gate x={910} y={310} w={46} h={110} g={g("east_gate")} label="EAST" vertical onSelect={() => setSelected("east_gate")} />

        {/* cameras */}
        {(twin?.cameras || []).map((c: any) => {
          const zz = zones[c.zone_code];
          if (!zz) return null;
          const cx = (zz.x || 100) + 16;
          const cy = (zz.y || 100) + 16;
          return (
            <g key={c.camera_id} opacity={c.status === "ONLINE" ? 1 : 0.35}>
              <circle cx={cx} cy={cy} r="4" fill={c.status === "ONLINE" ? "#00e5ff" : "#ff3d5a"} />
              <circle cx={cx} cy={cy} r="9" fill="none" stroke="#00e5ff" strokeOpacity="0.4" />
            </g>
          );
        })}

        {/* alert pulses */}
        {Object.values(zones).map((zn: any) => {
          if (zn.density !== "HIGH" && zn.density !== "CRITICAL") return null;
          return (
            <circle
              key={"pulse-" + zn.code}
              cx={zn.x + zn.w / 2}
              cy={zn.y + zn.h / 2}
              r="16"
              fill="none"
              stroke={zn.density === "CRITICAL" ? "#ff3d5a" : "#ffb020"}
              strokeWidth="1.5"
              className="pulse-ring"
              style={{ transformOrigin: `${zn.x + zn.w / 2}px ${zn.y + zn.h / 2}px` }}
            />
          );
        })}

        <text x="36" y="680" fill="#475569" fontFamily="IBM Plex Mono" fontSize="9">
          TAP A ZONE FOR LIVE STATE  ·  HEAT = ANONYMOUS DENSITY
        </text>
      </svg>

      {selected && (zones[selected] || gates[selected] || parking[selected]) && (
        <ZoneCard
          zone={zones[selected]}
          gate={gates[selected]}
          parking={parking[selected]}
          onClose={() => setSelected(null)}
        />
      )}
    </div>
  );
}

function Building({ z, x, y, w, h, selected, onSelect, round = 6, restricted = false, parking }: any) {
  if (!z?.code) {
    z = z || {};
  }
  const dens = z.density || "LOW";
  const isSel = selected === z.code;
  return (
    <g
      onClick={() => onSelect(z.code)}
      style={{ cursor: "pointer" }}
      transform={`translate(${x},${y})`}
    >
      <rect
        width={w}
        height={h}
        rx={round}
        className={DENSITY_CLASS[dens] || "heatmap-low"}
        strokeWidth={isSel ? 2.4 : 1}
        fillOpacity={0.85}
      />
      {restricted && (
        <rect width={w} height={h} rx={round} fill="none" stroke="#ff3d5a" strokeDasharray="4 3" />
      )}
      <text x={10} y={18} fill="#e2e8f0" fontFamily="Rajdhani" fontSize="12" fontWeight="700">
        {(z.name || "").toUpperCase()}
      </text>
      <text x={10} y={36} fill="#94a3b8" fontFamily="IBM Plex Mono" fontSize="10">
        {parking
          ? `${parking.occupied}/${parking.total}  ${parking.occupancy}%`
          : `PPL ${z.people ?? "—"}   ${dens}`}
      </text>
      {z.event && (
        <text x={10} y={h - 12} fill="#00e5ff" fontFamily="IBM Plex Mono" fontSize="9">
          {z.event}
        </text>
      )}
    </g>
  );
}

function Gate({ x, y, w, h, g, label, vertical, onSelect }: any) {
  const closed = g?.status === "CLOSED";
  return (
    <g onClick={onSelect} style={{ cursor: "pointer" }} transform={`translate(${x},${y})`}>
      <rect
        width={w}
        height={h}
        rx="4"
        fill={closed ? "rgba(255,61,90,0.25)" : "rgba(0,229,255,0.08)"}
        stroke={closed ? "#ff3d5a" : "#00e5ff"}
        strokeWidth="1.4"
      />
      <text
        x={vertical ? 10 : 10}
        y={vertical ? 18 : 16}
        fill="#e2e8f0"
        fontFamily="IBM Plex Mono"
        fontSize="9"
      >
        {label} {closed ? "· CLOSED" : ""}
      </text>
      {!vertical && (
        <text x={10} y={30} fill="#94a3b8" fontFamily="IBM Plex Mono" fontSize="9">
          IN {g?.incoming ?? 0}/m  OUT {g?.outgoing ?? 0}/m
        </text>
      )}
    </g>
  );
}

function ZoneCard({ zone, gate, parking, onClose }: any) {
  const title = zone?.name || gate?.name || parking?.name || "Zone";
  return (
    <div className="absolute right-4 top-4 w-72 panel p-4 z-10">
      <div className="flex justify-between items-start">
        <div>
          <div className="kicker">Live twin node</div>
          <div className="text-lg font-display">{title}</div>
        </div>
        <button onClick={onClose} className="text-slate-400 text-xs">
          CLOSE
        </button>
      </div>
      {zone && (
        <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
          <Stat k="People" v={zone.people} />
          <Stat k="Density" v={zone.density} />
          <Stat k="Growth" v={`${zone.growth_rate > 0 ? "+" : ""}${zone.growth_rate}`} />
          <Stat k="Risk" v={zone.risk} />
          {zone.event && <Stat k="Event" v={zone.event} />}
          <Stat k="Capacity" v={zone.capacity} />
        </div>
      )}
      {gate && (
        <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
          <Stat k="Status" v={gate.status} />
          <Stat k="Traffic" v={gate.traffic} />
          <Stat k="Incoming" v={`${gate.incoming}/min`} />
          <Stat k="Outgoing" v={`${gate.outgoing}/min`} />
        </div>
      )}
      {parking && (
        <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
          <Stat k="Occupied" v={parking.occupied} />
          <Stat k="Available" v={parking.available} />
          <Stat k="Occupancy" v={`${parking.occupancy}%`} />
          <Stat k="Growth/10m" v={parking.growth_per_10m} />
        </div>
      )}
    </div>
  );
}

function Stat({ k, v }: any) {
  return (
    <div className="bg-black/30 px-2 py-1.5 border border-white/5">
      <div className="kicker">{k}</div>
      <div className="num text-cyan-100">{v ?? "—"}</div>
    </div>
  );
}
