"""Anonymous computer vision — person/vehicle counting, no identity, no faces."""
from __future__ import annotations

import threading
import time
import uuid
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .config import FRAME_DIR, UPLOAD_DIR
from .twin import get_twin

JOBS: dict[str, dict] = {}


def _hog():
    hog = cv2.HOGDescriptor()
    hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
    return hog


_HOG = None


def get_hog():
    global _HOG
    if _HOG is None:
        _HOG = _hog()
    return _HOG


def detect_frame(bgr: np.ndarray) -> dict:
    """Detect people (HOG) and vehicle-like blobs. Returns anonymous boxes."""
    h, w = bgr.shape[:2]
    scale = 640 / max(w, 1)
    small = cv2.resize(bgr, (int(w * scale), int(h * scale))) if w > 640 else bgr
    sh, sw = small.shape[:2]
    people = []
    try:
        rects, weights = get_hog().detectMultiScale(small, winStride=(8, 8), padding=(8, 8), scale=1.05)
        for (x, y, bw, bh), conf in zip(rects, weights):
            people.append(
                {
                    "cls": "person",
                    "conf": float(min(0.99, max(0.45, conf / 3 if conf > 1 else conf))),
                    "xyxy": [
                        int(x / (sw / w)),
                        int(y / (sh / h)),
                        int((x + bw) / (sw / w)),
                        int((y + bh) / (sh / h)),
                    ],
                }
            )
    except Exception:
        people = []

    vehicles = []
    try:
        hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
        # asphalt-adjacent moving-ish blobs approximated by dark mid-size contours
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_OTSU + cv2.THRESH_BINARY)
        th = cv2.bitwise_not(th)
        contours, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for c in contours:
            x, y, bw, bh = cv2.boundingRect(c)
            area = bw * bh
            if 1200 < area < sw * sh * 0.12 and 1.1 < (bw / max(bh, 1)) < 4.2:
                vehicles.append(
                    {
                        "cls": "vehicle",
                        "conf": 0.62,
                        "xyxy": [
                            int(x / (sw / w)),
                            int(y / (sh / h)),
                            int((x + bw) / (sw / w)),
                            int((y + bh) / (sh / h)),
                        ],
                    }
                )
        vehicles = vehicles[:12]
    except Exception:
        vehicles = []

    # Crowd density from people count vs frame area
    n = len(people)
    if n >= 18:
        density = "CRITICAL"
    elif n >= 10:
        density = "HIGH"
    elif n >= 4:
        density = "MEDIUM"
    else:
        density = "LOW"

    annotated = bgr.copy()
    for d in people:
        x1, y1, x2, y2 = d["xyxy"]
        cv2.rectangle(annotated, (x1, y1), (x2, y2), (0, 229, 255), 2)
        cv2.putText(annotated, "PERSON", (x1, max(14, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 229, 255), 1, cv2.LINE_AA)
    for d in vehicles:
        x1, y1, x2, y2 = d["xyxy"]
        cv2.rectangle(annotated, (x1, y1), (x2, y2), (255, 176, 32), 2)
        cv2.putText(annotated, "VEHICLE", (x1, max(14, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 176, 32), 1, cv2.LINE_AA)
    banner = f"ANON CV  |  people {n}  vehicles {len(vehicles)}  density {density}  |  no identity"
    cv2.rectangle(annotated, (0, 0), (w, 28), (8, 12, 20), -1)
    cv2.putText(annotated, banner, (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 229, 255), 1, cv2.LINE_AA)

    return {
        "people": n,
        "vehicles": len(vehicles),
        "density": density,
        "detections": people + vehicles,
        "annotated": annotated,
    }


def process_video(path: Path, camera_id: str = "UPLOAD") -> str:
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {
        "id": job_id,
        "status": "RUNNING",
        "camera_id": camera_id,
        "frames": 0,
        "people_avg": 0,
        "vehicles_avg": 0,
        "density": "LOW",
        "timeline": [],
        "preview": None,
        "error": None,
    }

    def worker():
        cap = cv2.VideoCapture(str(path))
        if not cap.isOpened():
            JOBS[job_id]["status"] = "ERROR"
            JOBS[job_id]["error"] = "Could not open video"
            return
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        fps = cap.get(cv2.CAP_PROP_FPS) or 16
        step = max(1, int(fps * 1.2))
        people_sum = 0
        veh_sum = 0
        n = 0
        idx = 0
        last_preview = None
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            if idx % step != 0:
                idx += 1
                continue
            try:
                result = detect_frame(frame)
            except Exception as e:
                idx += 1
                continue
            n += 1
            people_sum += result["people"]
            veh_sum += result["vehicles"]
            tsec = idx / max(fps, 1)
            JOBS[job_id]["timeline"].append(
                {
                    "t": round(tsec, 1),
                    "people": result["people"],
                    "vehicles": result["vehicles"],
                    "density": result["density"],
                }
            )
            JOBS[job_id]["frames"] = n
            JOBS[job_id]["people_avg"] = round(people_sum / max(n, 1), 2)
            JOBS[job_id]["vehicles_avg"] = round(veh_sum / max(n, 1), 2)
            JOBS[job_id]["density"] = result["density"]
            last_preview = result["annotated"]
            idx += 1
            if n >= 40:
                break
        cap.release()
        if last_preview is not None:
            out = FRAME_DIR / f"{job_id}.jpg"
            cv2.imwrite(str(out), last_preview)
            JOBS[job_id]["preview"] = str(out.name)
        JOBS[job_id]["status"] = "DONE"
        twin = get_twin()
        for c in twin.state["cameras"]:
            if camera_id != "UPLOAD" and c["camera_id"] != camera_id:
                continue
            if camera_id == "UPLOAD" and c["camera_id"] != "CAM-002":
                continue
            c["people"] = int(JOBS[job_id]["people_avg"])
            c["vehicles"] = int(JOBS[job_id]["vehicles_avg"])
            c["source_type"] = "UPLOAD"
            break

    threading.Thread(target=worker, daemon=True).start()
    return job_id


def generate_demo_frame(camera: dict) -> np.ndarray:
    """Synthetic CCTV-like frame so demo cameras have a visual without hardware."""
    w, h = 960, 540
    img = np.zeros((h, w, 3), dtype=np.uint8)
    # night campus palette
    img[:, :] = (18, 22, 32)
    rng = np.random.RandomState((hash(camera["camera_id"]) + int(time.time() / 2)) % 2**31)
    # ground
    img[int(h * 0.45) :, :] = (28, 32, 40)
    # buildings silhouettes
    cv2.rectangle(img, (40, 80), (260, 300), (36, 42, 58), -1)
    cv2.rectangle(img, (700, 60), (920, 280), (40, 48, 64), -1)
    cv2.rectangle(img, (300, 40), (620, 200), (32, 38, 52), -1)
    # road
    cv2.rectangle(img, (0, 360), (w, 500), (22, 24, 28), -1)
    cv2.line(img, (0, 430), (w, 430), (80, 80, 40), 2)
    people = int(camera.get("people", 20) / 12)
    vehicles = int(camera.get("vehicles", 4) / 2)
    dets_people = []
    for i in range(max(3, min(28, people))):
        x = int(rng.randint(40, w - 40))
        y = int(rng.randint(int(h * 0.42), h - 50))
        bw, bh = 18, 40
        color = (0, 229, 255)
        cv2.rectangle(img, (x, y), (x + bw, y + bh), color, 2)
        dets_people.append((x, y, bw, bh))
    for i in range(max(1, min(10, vehicles))):
        x = int(rng.randint(20, w - 90))
        y = int(rng.randint(370, 470))
        cv2.rectangle(img, (x, y), (x + 70, y + 28), (255, 176, 32), 2)
    # scanline
    for y in range(0, h, 4):
        img[y, :] = (img[y, :] * 0.92).astype(np.uint8)
    banner = f"{camera['camera_id']}  {camera['location']}  |  ANON  people~{camera.get('people', 0)}  veh~{camera.get('vehicles', 0)}"
    cv2.rectangle(img, (0, 0), (w, 32), (5, 8, 14), -1)
    cv2.putText(img, banner, (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 229, 255), 1, cv2.LINE_AA)
    cv2.putText(img, "DEMO FEED — no identity", (w - 320, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (122, 139, 163), 1, cv2.LINE_AA)
    return img


_FRAME_CACHE: dict[str, float] = {}


def save_camera_jpeg(camera_id: str) -> Path:
    path = FRAME_DIR / f"{camera_id}.jpg"
    now = time.time()
    if path.exists() and now - _FRAME_CACHE.get(camera_id, 0) < 1.2:
        return path
    twin = get_twin()
    cam = next((c for c in twin.state["cameras"] if c["camera_id"] == camera_id), None)
    if not cam:
        cam = {"camera_id": camera_id, "location": "Unknown", "people": 0, "vehicles": 0}
    frame = generate_demo_frame(cam)
    cv2.imwrite(str(path), frame)
    _FRAME_CACHE[camera_id] = now
    return path
