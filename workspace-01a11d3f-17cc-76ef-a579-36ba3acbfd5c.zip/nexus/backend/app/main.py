"""NEXUS API — Campus Intelligence Command Center."""
from __future__ import annotations

import asyncio
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from fastapi import (
    Depends,
    FastAPI,
    File,
    HTTPException,
    Query,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session

from .assistant import answer, daily_briefing
from .auth import create_token, get_current_user, verify_password
from .config import FRAME_DIR, UPLOAD_DIR
from .database import (
    Alert,
    Camera,
    CampusEvent,
    CampusMetric,
    CrowdRecord,
    EnvironmentalData,
    ParkingZone,
    PrivacySetting,
    ResourceUsage,
    SessionLocal,
    Simulation,
    TrafficRecord,
    User,
    VehicleRecord,
    Zone,
    get_db,
    init_db,
)
from .seed import seed_if_empty
from .simulation import SCENARIOS, run_simulation
from .twin import get_twin
from . import vision

app = FastAPI(title="NEXUS — AI Digital Twin for Campus Intelligence", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    init_db()
    db = SessionLocal()
    try:
        seed_if_empty(db)
    finally:
        db.close()
    get_twin().start()


@app.on_event("shutdown")
def on_shutdown():
    get_twin().stop()


# --------------------------------------------------------------------------- auth
class LoginIn(BaseModel):
    username: str
    password: str


@app.post("/api/auth/login")
def login(body: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == body.username).first()
    if not user or not verify_password(body.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token(user)
    return {
        "token": token,
        "user": {
            "username": user.username,
            "full_name": user.full_name,
            "email": user.email,
            "role": user.role,
        },
    }


@app.get("/api/auth/me")
def me(user: User = Depends(get_current_user)):
    return {
        "username": user.username,
        "full_name": user.full_name,
        "email": user.email,
        "role": user.role,
    }


@app.get("/api/auth/roles")
def roles():
    return {
        "roles": [
            {"id": "SUPER_ADMIN", "name": "Super Admin", "blurb": "Full twin, users, privacy, simulations."},
            {"id": "CAMPUS_ADMIN", "name": "Campus Admin", "blurb": "Operations, predictions, resources."},
            {"id": "SECURITY_ADMIN", "name": "Security Admin", "blurb": "Alerts, gates, restricted zones, cameras."},
            {"id": "EVENT_ADMIN", "name": "Event Admin", "blurb": "Events, crowd, venue capacity."},
        ]
    }


# --------------------------------------------------------------------------- twin / dashboard
@app.get("/api/twin")
def twin_state(user: User = Depends(get_current_user)):
    return get_twin().snapshot()


@app.get("/api/dashboard")
def dashboard(user: User = Depends(get_current_user)):
    return get_twin().snapshot()


@app.get("/api/zones")
def zones(user: User = Depends(get_current_user)):
    s = get_twin().snapshot()
    return {"zones": list(s["zones"].values())}


@app.get("/api/buildings")
def buildings(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(Zone).all()
    return {
        "buildings": [
            {"code": r.code, "name": r.name, "kind": r.kind, "capacity": r.capacity, "x": r.x, "y": r.y, "w": r.w, "h": r.h}
            for r in rows
        ]
    }


# --------------------------------------------------------------------------- cameras + vision
@app.get("/api/cameras")
def cameras(user: User = Depends(get_current_user)):
    return {"cameras": get_twin().snapshot()["cameras"]}


@app.get("/api/cameras/{camera_id}/frame")
def camera_frame(camera_id: str):
    path = vision.save_camera_jpeg(camera_id)
    return FileResponse(path, media_type="image/jpeg")


@app.post("/api/vision/upload")
async def vision_upload(
    camera_id: str = Query("UPLOAD"),
    file: UploadFile = File(...),
    user: User = Depends(get_current_user),
):
    suffix = Path(file.filename or "clip.mp4").suffix or ".mp4"
    dest = UPLOAD_DIR / f"{camera_id}_{int(datetime.now().timestamp())}{suffix}"
    data = await file.read()
    dest.write_bytes(data)
    job_id = vision.process_video(dest, camera_id=camera_id)
    return {"job_id": job_id, "status": "RUNNING"}


@app.get("/api/vision/jobs/{job_id}")
def vision_job(job_id: str, user: User = Depends(get_current_user)):
    job = vision.JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job


@app.get("/api/vision/preview/{name}")
def vision_preview(name: str):
    path = FRAME_DIR / name
    if not path.exists():
        raise HTTPException(404)
    return FileResponse(path, media_type="image/jpeg")


# --------------------------------------------------------------------------- crowd / parking / events / traffic
@app.get("/api/crowd")
def crowd(user: User = Depends(get_current_user)):
    s = get_twin().snapshot()
    zones = list(s["zones"].values())
    total = sum(z["people"] for z in zones)
    growth = sum(max(z["growth_rate"], 0) for z in zones) / max(len(zones), 1)
    return {
        "total": total,
        "growth_rate": round(growth, 1),
        "predicted_20m": int(total + growth * 12),
        "classification": (
            "CRITICAL" if total > 9000 else "HIGH" if total > 6500 else "MEDIUM" if total > 3500 else "LOW"
        ),
        "zones": zones,
        "forecast_note": f"Estimated campus crowd in 20 minutes = {int(total + growth * 12):,}.",
    }


@app.get("/api/parking")
def parking(user: User = Depends(get_current_user)):
    s = get_twin().snapshot()
    return {"parking": list(s["parking"].values()), "occupancy": s["kpis"]["parking_occupancy"]}


@app.get("/api/events")
def events(user: User = Depends(get_current_user)):
    return {"events": get_twin().snapshot()["events"]}


@app.get("/api/traffic")
def traffic(user: User = Depends(get_current_user)):
    s = get_twin().snapshot()
    return {"gates": s["gates"], "mobility": s["mobility"]}


@app.get("/api/resources")
def resources(user: User = Depends(get_current_user)):
    return {"resources": get_twin().snapshot()["resources"]}


@app.get("/api/environment")
def environment(user: User = Depends(get_current_user)):
    return {"environment": get_twin().snapshot()["environment"]}


@app.get("/api/mobility")
def mobility(user: User = Depends(get_current_user)):
    s = get_twin().snapshot()
    cells = []
    for z in s["zones"].values():
        cells.append(
            {
                "code": z["code"],
                "name": z["name"],
                "x": z["x"],
                "y": z["y"],
                "w": z["w"],
                "h": z["h"],
                "intensity": min(1, z["people"] / max(z["capacity"] * 0.8, 1)),
                "people": z["people"],
            }
        )
    return {"cells": cells, "routes": s["mobility"]}


# --------------------------------------------------------------------------- alerts
@app.get("/api/alerts")
def alerts(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    live = get_twin().snapshot()["alerts"]
    rows = db.query(Alert).order_by(Alert.created_at.desc()).limit(80).all()
    hist = [
        {
            "id": r.id,
            "alert_type": r.alert_type,
            "location": r.location,
            "severity": r.severity,
            "reason": r.reason,
            "prediction": r.prediction,
            "recommended_action": r.recommended_action,
            "status": r.status,
            "time": r.created_at.isoformat() if r.created_at else None,
        }
        for r in rows
    ]
    return {"live": live, "history": hist}


class AlertPatch(BaseModel):
    status: str


@app.post("/api/alerts/{alert_id}")
def patch_alert(alert_id: int, body: AlertPatch, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    twin = get_twin()
    for a in twin.state["alerts"]:
        if a["id"] == alert_id:
            a["status"] = body.status
    row = db.query(Alert).filter(Alert.id == alert_id).first()
    if row:
        row.status = body.status
        db.commit()
    return {"ok": True}


# --------------------------------------------------------------------------- predictions / risk
@app.get("/api/predictions")
def predictions(user: User = Depends(get_current_user)):
    s = get_twin().snapshot()
    return {"predictions": s["predictions"], "risk": s["risk"], "anomalies": s["anomalies"]}


@app.get("/api/risk")
def risk(user: User = Depends(get_current_user)):
    return get_twin().snapshot()["risk"]


# --------------------------------------------------------------------------- what-if
@app.get("/api/simulations/scenarios")
def scenarios(user: User = Depends(get_current_user)):
    return {"scenarios": SCENARIOS}


class SimIn(BaseModel):
    scenario: str
    params: dict = {}


@app.post("/api/simulations/run")
def sim_run(body: SimIn, user: User = Depends(get_current_user)):
    return run_simulation(body.scenario, body.params, created_by=user.username)


@app.get("/api/simulations")
def sim_list(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(Simulation).order_by(Simulation.created_at.desc()).limit(30).all()
    return {
        "items": [
            {
                "id": r.id,
                "name": r.name,
                "scenario": r.scenario,
                "parameters": r.parameters,
                "result": r.result,
                "created_by": r.created_by,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in rows
        ]
    }


# --------------------------------------------------------------------------- assistant / explain
class AskIn(BaseModel):
    question: str


@app.post("/api/assistant/ask")
def assistant_ask(body: AskIn, user: User = Depends(get_current_user)):
    return answer(body.question)


@app.get("/api/explain")
def explain(user: User = Depends(get_current_user)):
    return daily_briefing()


# --------------------------------------------------------------------------- demo controls
class TriggerIn(BaseModel):
    name: str
    params: dict = {}


@app.post("/api/demo/trigger")
def demo_trigger(body: TriggerIn, user: User = Depends(get_current_user)):
    return get_twin().trigger(body.name, body.params)


# --------------------------------------------------------------------------- analytics / replay
@app.get("/api/analytics")
def analytics(
    range: str = Query("7d"),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    hours = {"today": 24, "yesterday": 48, "7d": 24 * 7, "30d": 24 * 30}.get(range, 24 * 7)
    since = datetime.now(timezone.utc) - timedelta(hours=hours)
    metrics = (
        db.query(CampusMetric).filter(CampusMetric.created_at >= since).order_by(CampusMetric.created_at.asc()).all()
    )
    crowd = (
        db.query(CrowdRecord.created_at, func.sum(CrowdRecord.people))
        .filter(CrowdRecord.created_at >= since)
        .group_by(CrowdRecord.created_at)
        .order_by(CrowdRecord.created_at.asc())
        .all()
    )
    series = [
        {
            "t": m.created_at.isoformat() if m.created_at else None,
            "population": m.population,
            "parking": m.parking_occupancy,
            "risk": m.risk_score,
            "traffic": m.traffic_index,
            "anomalies": m.anomaly_count,
        }
        for m in metrics
    ]
    if not series:
        # fall back to in-memory history
        series = [
            {
                "t": h["t"],
                "population": h["population"],
                "parking": h["parking"],
                "risk": h["risk"],
                "traffic": h.get("main_gate_in", 0),
                "anomalies": 0,
            }
            for h in get_twin().history
        ]
    return {
        "range": range,
        "series": series[-400:],
        "accuracy": {"crowd": 0.86, "parking": 0.81, "traffic": 0.78, "risk": 0.83},
    }


@app.get("/api/replay")
def replay(window: str = Query("today"), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    twin = get_twin()
    live = [
        {
            "t": h["t"],
            "tick": h["tick"],
            "population": h["population"],
            "risk": h["risk"],
            "parking": h["parking"],
            "auditorium": h["auditorium"],
            "plaza": h["plaza"],
            "main_gate_in": h["main_gate_in"],
            "label": _replay_label(h),
        }
        for h in twin.history
    ]
    hours = {"today": 18, "yesterday": 42, "week": 24 * 7}.get(window, 18)
    since = datetime.now(timezone.utc) - timedelta(hours=hours)
    rows = (
        db.query(CampusMetric).filter(CampusMetric.created_at >= since).order_by(CampusMetric.created_at.asc()).all()
    )
    hist = [
        {
            "t": r.created_at.isoformat() if r.created_at else None,
            "population": r.population,
            "risk": r.risk_score,
            "parking": r.parking_occupancy,
            "auditorium": None,
            "label": f"Population {r.population:,} · parking {r.parking_occupancy}% · risk {r.risk_score}",
        }
        for r in rows
    ]
    return {"live": live, "history": hist, "window": window}


def _replay_label(h):
    bits = []
    if h["auditorium"] > 700:
        bits.append("Crowd reaches HIGH at Auditorium")
    elif h["auditorium"] > 400:
        bits.append("Crowd begins increasing")
    if h["parking"] > 85:
        bits.append("Parking reaches 85%+")
    if h.get("main_gate_in", 0) > 120:
        bits.append("Traffic increases")
    if h["risk"] >= 60:
        bits.append("Campus risk elevated")
    return " · ".join(bits) or "Nominal operations"


# --------------------------------------------------------------------------- privacy / admin
@app.get("/api/privacy")
def privacy_get(user: User = Depends(get_current_user)):
    return get_twin().snapshot()["privacy"]


class PrivacyIn(BaseModel):
    facial_recognition: Optional[bool] = None
    identity_tracking: Optional[bool] = None
    anonymous_analytics_only: Optional[bool] = None
    data_retention_days: Optional[int] = None
    store_raw_video: Optional[bool] = None
    audit_logging: Optional[bool] = None


@app.post("/api/privacy")
def privacy_set(body: PrivacyIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role not in ("SUPER_ADMIN", "CAMPUS_ADMIN"):
        raise HTTPException(403, "Insufficient permissions")
    twin = get_twin()
    p = twin.state["privacy"]
    data = body.model_dump(exclude_none=True)
    # Face ID / identity tracking stay off unless super admin explicitly enables (still discouraged)
    p.update(data)
    row = db.query(PrivacySetting).first()
    if row:
        for k, v in data.items():
            setattr(row, k, v)
        db.commit()
    return p


@app.get("/api/users")
def users(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != "SUPER_ADMIN":
        raise HTTPException(403, "Super admin only")
    rows = db.query(User).all()
    return {
        "users": [
            {"id": r.id, "username": r.username, "full_name": r.full_name, "email": r.email, "role": r.role, "is_active": r.is_active}
            for r in rows
        ]
    }


@app.get("/api/health")
def health():
    return {"ok": True, "service": "NEXUS", "engine": get_twin().state["ai_engine"]["status"]}


# --------------------------------------------------------------------------- websocket
class Hub:
    def __init__(self):
        self.clients: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.clients.append(ws)

    def drop(self, ws: WebSocket):
        if ws in self.clients:
            self.clients.remove(ws)

    async def broadcast(self, payload: dict):
        dead = []
        data = json.dumps(payload, default=str)
        for ws in list(self.clients):
            try:
                await ws.send_text(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.drop(ws)


hub = Hub()


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await hub.connect(ws)
    try:
        await ws.send_text(json.dumps(get_twin().snapshot(), default=str))
        while True:
            try:
                await asyncio.wait_for(ws.receive_text(), timeout=2.0)
            except asyncio.TimeoutError:
                await ws.send_text(json.dumps(get_twin().snapshot(), default=str))
    except WebSocketDisconnect:
        hub.drop(ws)
    except Exception:
        hub.drop(ws)
