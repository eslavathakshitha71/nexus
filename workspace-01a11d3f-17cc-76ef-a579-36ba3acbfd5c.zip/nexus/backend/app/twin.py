"""NEXUS Digital Twin — live campus state, demo engine, anomalies, predictions."""
from __future__ import annotations

import math
import random
import threading
import time
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy.orm import Session

from .database import (
    Alert,
    Building,
    Camera,
    CampusEvent,
    CampusMetric,
    CrowdRecord,
    EnvironmentalData,
    ParkingZone,
    Prediction,
    ResourceUsage,
    SessionLocal,
    TrafficRecord,
    VehicleRecord,
    Zone,
    utcnow,
)

LOCK = threading.RLock()


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _density(people: int, capacity: int) -> str:
    if capacity <= 0:
        return "LOW"
    r = people / capacity
    if r >= 0.95:
        return "CRITICAL"
    if r >= 0.75:
        return "HIGH"
    if r >= 0.45:
        return "MEDIUM"
    return "LOW"


def _cong(volume: int, cap: int = 220) -> str:
    r = volume / cap
    if r >= 0.9:
        return "CRITICAL"
    if r >= 0.7:
        return "HIGH"
    if r >= 0.4:
        return "MODERATE"
    return "LOW"


def _level_from_score(score: float) -> str:
    if score >= 80:
        return "CRITICAL"
    if score >= 60:
        return "ELEVATED"
    if score >= 35:
        return "MODERATE"
    return "NORMAL"


def _status_from_score(score: float) -> str:
    if score >= 80:
        return "critical"
    if score >= 60:
        return "elevated"
    if score >= 35:
        return "moderate"
    return "normal"


# Typical occupancy curves for a working day (hour -> 0..1 factor)
def _diurnal(hour: float) -> float:
    # Morning rush 8-10, lunch 12-14, evening 16-19
    return (
        0.12
        + 0.55 * math.exp(-((hour - 9.2) ** 2) / 4.5)
        + 0.42 * math.exp(-((hour - 13.0) ** 2) / 3.2)
        + 0.50 * math.exp(-((hour - 17.5) ** 2) / 5.5)
    )


ZONE_DEFS = [
    dict(code="main_gate", name="Main Gate", kind="gate", capacity=400, x=430, y=620, w=140, h=50),
    dict(code="north_gate", name="North Gate", kind="gate", capacity=250, x=430, y=18, w=140, h=42),
    dict(code="east_gate", name="East Gate", kind="gate", capacity=220, x=860, y=340, w=50, h=110),
    dict(code="auditorium", name="Auditorium", kind="venue", capacity=1500, x=560, y=160, w=170, h=120),
    dict(code="cafeteria", name="Cafeteria", kind="amenity", capacity=700, x=560, y=320, w=150, h=90),
    dict(code="library", name="Central Library", kind="amenity", capacity=900, x=80, y=150, w=150, h=110),
    dict(code="academic_a", name="Academic Block A", kind="academic", capacity=1200, x=80, y=300, w=160, h=100),
    dict(code="academic_b", name="Academic Block B", kind="academic", capacity=1100, x=80, y=430, w=160, h=100),
    dict(code="admin", name="Admin Block", kind="admin", capacity=300, x=280, y=150, w=120, h=80),
    dict(code="sports", name="Sports Complex", kind="recreation", capacity=800, x=760, y=70, w=150, h=110),
    dict(code="hostel", name="Residence Halls", kind="residential", capacity=1400, x=80, y=560, w=170, h=80),
    dict(code="plaza", name="Central Plaza", kind="open", capacity=2000, x=300, y=300, w=220, h=140),
    dict(code="lawn", name="Open Lawn", kind="open", capacity=2500, x=560, y=440, w=180, h=100),
    dict(code="transport", name="Transport Hub", kind="transport", capacity=400, x=300, y=560, w=140, h=70),
    dict(code="restricted", name="Research Lab (Restricted)", kind="restricted", capacity=80, x=760, y=210, w=130, h=80),
    dict(code="road_central", name="Central Road", kind="road", capacity=300, x=300, y=470, w=430, h=36),
    dict(code="parking_a", name="Parking Zone A — Student", kind="parking", capacity=150, x=760, y=320, w=140, h=90),
    dict(code="parking_b", name="Parking Zone B — Faculty", kind="parking", capacity=80, x=760, y=430, w=140, h=70),
    dict(code="parking_c", name="Parking Zone C — Visitor", kind="parking", capacity=60, x=560, y=560, w=150, h=70),
    dict(code="parking_2w", name="Two-Wheeler Parking", kind="parking", capacity=320, x=430, y=560, w=110, h=50),
]

PARKING_DEFS = [
    dict(code="parking_a", name="Parking Zone A — Student 4W", category="STUDENT", total=150, typical=0.62),
    dict(code="parking_b", name="Parking Zone B — Faculty", category="FACULTY", total=80, typical=0.70),
    dict(code="parking_c", name="Parking Zone C — Visitor", category="VISITOR", total=60, typical=0.45),
    dict(code="parking_2w", name="Two-Wheeler Parking", category="TWO_WHEELER", total=320, typical=0.68),
]

CAMERA_DEFS = [
    dict(id="CAM-001", name="Main Gate Cam", location="Main Gate", zone="main_gate", fps=25),
    dict(id="CAM-002", name="Auditorium Cam", location="Auditorium Forecourt", zone="auditorium", fps=24),
    dict(id="CAM-003", name="Parking A Cam", location="Student Parking", zone="parking_a", fps=20),
    dict(id="CAM-004", name="Central Road Cam", location="Central Road", zone="road_central", fps=22),
    dict(id="CAM-005", name="Sports Cam", location="Sports Complex", zone="sports", fps=20),
    dict(id="CAM-006", name="Library Cam", location="Library Plaza", zone="library", fps=18),
    dict(id="CAM-007", name="Cafeteria Cam", location="Cafeteria", zone="cafeteria", fps=20),
    dict(id="CAM-008", name="East Gate Cam", location="East Gate", zone="east_gate", fps=22),
    dict(id="CAM-009", name="Restricted Zone Cam", location="Research Lab Perimeter", zone="restricted", fps=15),
    dict(id="CAM-010", name="North Gate Cam", location="North Gate", zone="north_gate", fps=22),
]

ROUTES = [
    dict(code="gate_main_to_plaza", name="Main Gate → Central Plaza", from_z="main_gate", to_z="plaza"),
    dict(code="plaza_to_auditorium", name="Plaza → Auditorium", from_z="plaza", to_z="auditorium"),
    dict(code="plaza_to_cafeteria", name="Plaza → Cafeteria", from_z="plaza", to_z="cafeteria"),
    dict(code="gate_east_to_parking", name="East Gate → Parking A", from_z="east_gate", to_z="parking_a"),
    dict(code="parking_to_auditorium", name="Parking A → Auditorium", from_z="parking_a", to_z="auditorium"),
    dict(code="hostel_to_academic", name="Hostels → Academic Blocks", from_z="hostel", to_z="academic_a"),
    dict(code="gate_north_to_sports", name="North Gate → Sports", from_z="north_gate", to_z="sports"),
    dict(code="transport_to_plaza", name="Transport Hub → Plaza", from_z="transport", to_z="plaza"),
]


class TwinEngine:
    def __init__(self):
        self.tick = 0
        self.running = False
        self.thread: threading.Thread | None = None
        self.listeners: list = []
        self.history: list[dict] = []  # in-memory snapshots for replay
        self.alert_seq = 100
        self.vision_jobs: dict[str, Any] = {}
        self.reset_to_normal(persist=False)

    # ------------------------------------------------------------------ init
    def reset_to_normal(self, persist: bool = True):
        with LOCK:
            # Virtual campus clock: late afternoon so the demo is always "alive"
            hour = 16.6
            d = max(_diurnal(hour), 0.72)
            rng = random.Random(42 + int(time.time()) % 97)

            zones = {}
            for z in ZONE_DEFS:
                cap = z["capacity"]
                if z["kind"] == "parking":
                    people = int(22 * d + rng.randint(4, 16))
                elif z["kind"] == "gate":
                    people = int(90 * d + rng.randint(12, 36))
                elif z["kind"] == "restricted":
                    people = rng.randint(6, 16)
                elif z["kind"] == "road":
                    people = int(110 * d + rng.randint(16, 40))
                elif z["code"] == "auditorium":
                    people = int(420 * d + rng.randint(20, 60))
                elif z["code"] == "cafeteria":
                    people = int(310 * d + rng.randint(20, 50))
                elif z["code"] == "plaza":
                    people = int(480 * d + rng.randint(30, 80))
                elif z["code"] == "library":
                    people = int(260 * d + rng.randint(10, 40))
                elif z["code"] in ("academic_a", "academic_b"):
                    people = int(380 * d + rng.randint(20, 50))
                elif z["code"] == "sports":
                    people = int(240 * d + rng.randint(20, 50))
                elif z["code"] == "hostel":
                    people = int(320 * d + rng.randint(20, 40))
                elif z["code"] == "lawn":
                    people = int(180 * d + rng.randint(10, 40))
                else:
                    people = int(cap * 0.28 * d + rng.randint(8, 36))
                people = int(_clamp(people, 0, cap))
                zones[z["code"]] = {
                    **z,
                    "people": people,
                    "density": _density(people, cap),
                    "growth_rate": round(rng.uniform(-4, 8), 1),
                    "direction": rng.choice(["IN", "OUT", "STABLE", "IN"]),
                    "risk": "LOW",
                    "event": None,
                    "vehicles": 0,
                    "restricted": z["kind"] == "restricted",
                }

            parking = {}
            for p in PARKING_DEFS:
                occ = int(p["total"] * p["typical"] * (0.55 + 0.7 * d) + rng.randint(-6, 6))
                occ = int(_clamp(occ, 4, p["total"] - 2))
                parking[p["code"]] = {
                    **p,
                    "occupied": occ,
                    "available": p["total"] - occ,
                    "occupancy": round(100 * occ / p["total"], 1),
                    "cars": int(occ * (0.15 if p["category"] == "TWO_WHEELER" else 0.85)),
                    "bikes": int(occ * (0.85 if p["category"] == "TWO_WHEELER" else 0.12)),
                    "other": 0,
                    "growth_per_10m": round(rng.uniform(-2, 6), 1),
                    "typical_range": [int(p["total"] * (p["typical"] - 0.12)), int(p["total"] * (p["typical"] + 0.12))],
                }
                parking[p["code"]]["other"] = max(
                    0, occ - parking[p["code"]]["cars"] - parking[p["code"]]["bikes"]
                )

            gates = {
                "main_gate": {
                    "code": "main_gate",
                    "name": "Main Gate",
                    "status": "OPEN",
                    "incoming": int(70 * d + rng.randint(20, 50)),
                    "outgoing": int(45 * d + rng.randint(10, 40)),
                    "traffic": "MODERATE",
                    "vehicles_in": int(18 * d + 6),
                    "vehicles_out": int(12 * d + 4),
                },
                "north_gate": {
                    "code": "north_gate",
                    "name": "North Gate",
                    "status": "OPEN",
                    "incoming": int(28 * d + rng.randint(8, 20)),
                    "outgoing": int(22 * d + rng.randint(6, 16)),
                    "traffic": "LOW",
                    "vehicles_in": int(6 * d + 2),
                    "vehicles_out": int(5 * d + 2),
                },
                "east_gate": {
                    "code": "east_gate",
                    "name": "East Gate",
                    "status": "OPEN",
                    "incoming": int(36 * d + rng.randint(8, 22)),
                    "outgoing": int(24 * d + rng.randint(6, 18)),
                    "traffic": "LOW",
                    "vehicles_in": int(10 * d + 3),
                    "vehicles_out": int(7 * d + 2),
                },
            }
            for g in gates.values():
                g["traffic"] = _cong(g["incoming"] + g["outgoing"], 220)
                g["per_min_in"] = g["incoming"]
                g["per_min_out"] = g["outgoing"]

            events = [
                {
                    "id": 1,
                    "name": "TECHNOVA 2026",
                    "venue_code": "auditorium",
                    "venue": "Main Auditorium",
                    "expected": 1200,
                    "current": zones["auditorium"]["people"],
                    "predicted_peak": 980,
                    "capacity": 1500,
                    "risk": "LOW",
                    "status": "SCHEDULED",
                    "starts_in_min": 40,
                    "duration_min": 180,
                    "description": "Annual technology festival — keynotes, expo, hackathon showcase.",
                },
                {
                    "id": 2,
                    "name": "Inter-College Football Finals",
                    "venue_code": "sports",
                    "venue": "Sports Complex",
                    "expected": 420,
                    "current": zones["sports"]["people"],
                    "predicted_peak": 390,
                    "capacity": 800,
                    "risk": "LOW",
                    "status": "LIVE",
                    "starts_in_min": 0,
                    "duration_min": 110,
                    "description": "Championship match. Moderate spectator inflow expected.",
                },
            ]

            cameras = []
            for c in CAMERA_DEFS:
                cameras.append(
                    {
                        "camera_id": c["id"],
                        "name": c["name"],
                        "location": c["location"],
                        "zone_code": c["zone"],
                        "status": "ONLINE",
                        "ai_status": "ACTIVE",
                        "fps": c["fps"] + rng.uniform(-0.4, 0.4),
                        "source_type": "DEMO",
                        "people": zones[c["zone"]]["people"] if c["zone"] in zones else 0,
                        "vehicles": rng.randint(0, 18),
                        "last_update": _now().isoformat(),
                        "detections": [],
                    }
                )

            mobility = []
            for r in ROUTES:
                vol = int(40 * d + rng.randint(8, 40))
                mobility.append(
                    {
                        **r,
                        "volume": vol,
                        "congestion": _cong(vol, 160),
                        "direction": "FORWARD",
                        "peak": False,
                    }
                )

            env = {
                "temperature_c": round(31.5 + rng.uniform(-1.2, 1.8), 1),
                "humidity": round(52 + rng.uniform(-6, 10), 1),
                "condition": "Clear",
                "rain_mm": 0.0,
                "aqi": int(68 + rng.randint(-8, 12)),
                "wind_kmh": round(7 + rng.uniform(-2, 4), 1),
                "forecast": "Clear evening. 12% chance of light rain after 21:00.",
            }

            resources = {
                "electricity": {
                    "name": "Electricity",
                    "value": 4280,
                    "unit": "kWh/day",
                    "baseline": 4200,
                    "status": "NORMAL",
                },
                "water": {
                    "name": "Water",
                    "value": 186,
                    "unit": "kL/day",
                    "baseline": 190,
                    "status": "NORMAL",
                },
                "waste": {
                    "name": "Waste",
                    "value": 2.4,
                    "unit": "t/day",
                    "baseline": 2.2,
                    "status": "NORMAL",
                },
                "transport": {
                    "name": "Campus Shuttles",
                    "value": 14,
                    "unit": "active trips",
                    "baseline": 12,
                    "status": "NORMAL",
                },
                "event_facilities": {
                    "name": "Event Facilities",
                    "value": 2,
                    "unit": "venues live",
                    "baseline": 1,
                    "status": "NORMAL",
                },
            }

            self.state = {
                "campus": CAMPUS_META,
                "tick": 0,
                "mode": "normal",
                "demo_phase": "idle",
                "updated_at": _now().isoformat(),
                "zones": zones,
                "parking": parking,
                "gates": gates,
                "events": events,
                "cameras": cameras,
                "mobility": mobility,
                "environment": env,
                "resources": resources,
                "alerts": [],
                "anomalies": [],
                "predictions": [],
                "risk": {
                    "score": 22,
                    "level": "NORMAL",
                    "status": "normal",
                    "contributors": [],
                    "reasons": ["Campus operating within historical envelopes."],
                    "recommended_action": "Continue standard monitoring.",
                },
                "population": sum(z["people"] for z in zones.values()),
                "ai_engine": {
                    "status": "ONLINE",
                    "models": ["YOLOv8n-anon", "CrowdNet", "ParkPredict", "RiskFusion", "WhatIf-Sim"],
                    "fps_processed": 86,
                    "anonymization": True,
                    "identity_tracking": False,
                    "facial_recognition": False,
                },
                "privacy": {
                    "facial_recognition": False,
                    "identity_tracking": False,
                    "anonymous_analytics_only": True,
                    "data_retention_days": 30,
                    "store_raw_video": False,
                    "audit_logging": True,
                },
                "scenarios": [],
                "headline": "Campus operating normally. All systems nominal.",
            }
            self._active_scenarios: dict[str, dict] = {}
            self._event_started = False
            self._demo_auto = False
            self._recompute()
            if persist:
                self._persist_snapshot()

    # ------------------------------------------------------------------ scenarios
    def trigger(self, name: str, params: dict | None = None) -> dict:
        params = params or {}
        with LOCK:
            if name == "reset":
                self.reset_to_normal(persist=True)
                return self.snapshot()
            if name == "demo_sequence":
                self._demo_auto = True
                self._demo_t0 = time.time()
                self.state["demo_phase"] = "event_ramp"
                self.state["mode"] = "event"
                self._active_scenarios["technova"] = {"t": 0, "intensity": 0.15}
                self._note_alert(
                    "EVENT OVERCROWDING RISK",
                    "Auditorium",
                    "MEDIUM",
                    "TECHNOVA 2026 is going live. Crowd inflow detected at Main Gate and Plaza.",
                    "Crowd at auditorium may exceed 1,200 within 25 minutes.",
                    "Open overflow holding area at Central Plaza and staff additional exits.",
                )
            elif name in ("start_event", "event_crowd"):
                self.state["mode"] = "event"
                self._event_started = True
                self._active_scenarios["technova"] = {"t": 0, "intensity": float(params.get("intensity", 0.6))}
                for e in self.state["events"]:
                    if e["id"] == 1:
                        e["status"] = "LIVE"
                        e["starts_in_min"] = 0
                self.state["zones"]["auditorium"]["event"] = "TECHNOVA 2026"
                self._note_alert(
                    "EVENT OVERCROWDING RISK",
                    "Auditorium",
                    "MEDIUM",
                    "TECHNOVA 2026 is now live. Inflow accelerating from Main Gate and Parking A.",
                    "Peak crowd predicted above expected attendance.",
                    "Activate event crowd protocol and open Plaza overflow.",
                )
            elif name == "crowd_increase":
                self._active_scenarios["crowd_surge"] = {
                    "t": 0,
                    "zone": params.get("zone", "plaza"),
                    "amount": int(params.get("amount", 280)),
                }
            elif name == "vehicle_increase":
                self._active_scenarios["vehicles"] = {"t": 0, "mult": float(params.get("mult", 1.4))}
            elif name == "parking_shortage":
                self._active_scenarios["parking"] = {"t": 0, "target": float(params.get("occupancy", 0.93))}
            elif name == "gate_closure":
                gate = params.get("gate", "main_gate")
                self._active_scenarios["gate_closed"] = {"t": 0, "gate": gate}
                self.state["gates"][gate]["status"] = "CLOSED"
                self.state["gates"][gate]["incoming"] = 0
                self._note_alert(
                    "TRAFFIC CONGESTION PREDICTED",
                    self.state["gates"][gate]["name"],
                    "HIGH",
                    f"{self.state['gates'][gate]['name']} has been closed. Inbound flow will redistribute.",
                    "Congestion expected at remaining gates within 8–12 minutes.",
                    "Open East Gate express lane and redirect 35% of inbound traffic.",
                )
            elif name == "weather_change":
                cond = params.get("condition", "Heavy Rain")
                self._active_scenarios["weather"] = {"t": 0, "condition": cond}
                env = self.state["environment"]
                env["condition"] = cond
                if "Rain" in cond:
                    env["rain_mm"] = 18.0
                    env["humidity"] = 88
                    env["forecast"] = "Heavy rain for the next 90 minutes. Outdoor venues at disruption risk."
                    self._note_alert(
                        "ENVIRONMENTAL RISK",
                        "Open Lawn / Sports",
                        "HIGH",
                        "Heavy rain overlay active during live outdoor activity.",
                        "Outdoor event disruption likely. Pedestrian slowing + indoor surge.",
                        "Move overflow gatherings indoors and cover parking walkways.",
                    )
            elif name == "resource_anomaly":
                self._active_scenarios["resource"] = {"t": 0}
                self.state["resources"]["electricity"]["value"] = 5400
                self.state["resources"]["electricity"]["status"] = "ANOMALY"
                self._note_alert(
                    "UNUSUAL RESOURCE CONSUMPTION",
                    "Campus Grid",
                    "MEDIUM",
                    "Electricity draw is 28% above the daily historical baseline of 4,200 kWh.",
                    "Load likely driven by large event + extended HVAC + lighting.",
                    "Notify facilities. Shed non-critical facade lighting if the event extends.",
                )
            elif name == "restricted_activity":
                self._active_scenarios["restricted"] = {"t": 0}
                self.state["zones"]["restricted"]["people"] = 46
                self._note_alert(
                    "RESTRICTED ZONE ACTIVITY",
                    "Research Lab",
                    "HIGH",
                    "Anonymous movement count inside the restricted perimeter is 3.2× the normal envelope.",
                    "If growth continues, perimeter lock protocol may be required.",
                    "Dispatch security to the lab perimeter. No identity tracking will be used.",
                )
            elif name == "camera_offline":
                cam_id = params.get("camera_id", "CAM-009")
                for c in self.state["cameras"]:
                    if c["camera_id"] == cam_id:
                        c["status"] = "OFFLINE"
                        c["ai_status"] = "DEGRADED"
                self._note_alert(
                    "CAMERA OFFLINE",
                    cam_id,
                    "MEDIUM",
                    f"{cam_id} stopped sending frames.",
                    "Coverage gap in that zone until the feed is restored.",
                    "Switch to neighboring cameras and dispatch a technician.",
                )
            self._recompute()
            return self.snapshot()

    # ------------------------------------------------------------------ tick
    def step(self):
        with LOCK:
            self.tick += 1
            self.state["tick"] = self.tick
            rng = random.Random(self.tick * 17 + 3)

            if self._demo_auto:
                self._advance_demo()

            # Natural jitter
            for z in self.state["zones"].values():
                drift = rng.randint(-6, 8)
                # scenario modifiers
                if "technova" in self._active_scenarios and z["code"] in (
                    "auditorium",
                    "plaza",
                    "cafeteria",
                    "road_central",
                    "main_gate",
                    "parking_a",
                    "lawn",
                ):
                    boost = int(18 * self._active_scenarios["technova"]["intensity"])
                    if z["code"] == "auditorium":
                        boost = int(42 * self._active_scenarios["technova"]["intensity"])
                    drift += boost
                if "crowd_surge" in self._active_scenarios and z["code"] == self._active_scenarios["crowd_surge"]["zone"]:
                    drift += 22
                if z["kind"] == "restricted" and "restricted" in self._active_scenarios:
                    drift += rng.randint(0, 3)
                z["people"] = int(_clamp(z["people"] + drift, 0, z["capacity"]))
                z["growth_rate"] = round(drift * 1.7, 1)
                z["density"] = _density(z["people"], z["capacity"])
                z["direction"] = "IN" if drift > 3 else "OUT" if drift < -3 else "STABLE"

            # Parking
            for p in self.state["parking"].values():
                g = rng.uniform(-1.5, 2.4)
                if "technova" in self._active_scenarios:
                    g += 4.2 * self._active_scenarios["technova"]["intensity"]
                if "parking" in self._active_scenarios:
                    target = int(p["total"] * self._active_scenarios["parking"]["target"])
                    if p["occupied"] < target:
                        g += 6
                if "vehicles" in self._active_scenarios:
                    g += 3
                if "gate_closed" in self._active_scenarios and self._active_scenarios["gate_closed"]["gate"] == "main_gate":
                    if p["code"] == "parking_c":
                        g += 3
                    if p["code"] == "parking_a":
                        g += 2
                p["occupied"] = int(_clamp(p["occupied"] + g, 0, p["total"]))
                p["available"] = p["total"] - p["occupied"]
                p["occupancy"] = round(100 * p["occupied"] / p["total"], 1)
                p["growth_per_10m"] = round(g * 5, 1)
                if p["category"] == "TWO_WHEELER":
                    p["bikes"] = int(p["occupied"] * 0.92)
                    p["cars"] = int(p["occupied"] * 0.05)
                else:
                    p["cars"] = int(p["occupied"] * 0.88)
                    p["bikes"] = int(p["occupied"] * 0.08)
                p["other"] = max(0, p["occupied"] - p["cars"] - p["bikes"])

            # Gates
            closed = self._active_scenarios.get("gate_closed", {}).get("gate")
            spill = 0
            for code, g in self.state["gates"].items():
                if code == closed:
                    spill += 90
                    g["status"] = "CLOSED"
                    g["incoming"] = 0
                    g["outgoing"] = int(_clamp(g["outgoing"] * 0.4, 0, 40))
                    g["vehicles_in"] = 0
                    g["traffic"] = "CLOSED"
                    continue
                inc = g["incoming"] + rng.randint(-8, 10)
                if "technova" in self._active_scenarios:
                    inc += int(16 * self._active_scenarios["technova"]["intensity"])
                if "vehicles" in self._active_scenarios:
                    inc += 12
                g["incoming"] = int(_clamp(inc, 5, 260))
                g["outgoing"] = int(_clamp(g["outgoing"] + rng.randint(-6, 8), 4, 220))
                g["vehicles_in"] = int(g["incoming"] * 0.22)
                g["vehicles_out"] = int(g["outgoing"] * 0.18)
                g["traffic"] = _cong(g["incoming"] + g["outgoing"], 220)
            if closed:
                # redistribute
                others = [k for k in self.state["gates"] if k != closed]
                for k in others:
                    self.state["gates"][k]["incoming"] = int(
                        _clamp(self.state["gates"][k]["incoming"] + spill / max(len(others), 1), 0, 280)
                    )
                    self.state["gates"][k]["traffic"] = _cong(
                        self.state["gates"][k]["incoming"] + self.state["gates"][k]["outgoing"], 220
                    )

            # Mobility
            for m in self.state["mobility"]:
                m["volume"] = int(_clamp(m["volume"] + rng.randint(-8, 12), 5, 240))
                if "technova" in self._active_scenarios and m["to_z"] in ("auditorium", "plaza"):
                    m["volume"] = int(_clamp(m["volume"] + 18, 0, 260))
                if closed == "main_gate" and "main" in m["code"]:
                    m["volume"] = int(m["volume"] * 0.25)
                m["congestion"] = _cong(m["volume"], 160)
                m["peak"] = m["volume"] > 140

            # Events
            for e in self.state["events"]:
                z = self.state["zones"].get(e["venue_code"])
                if z:
                    e["current"] = z["people"]
                if e["id"] == 1 and "technova" in self._active_scenarios:
                    e["status"] = "LIVE"
                    e["predicted_peak"] = int(e["current"] + 38 * 8 * self._active_scenarios["technova"]["intensity"])
                    e["predicted_peak"] = min(e["predicted_peak"], int(e["capacity"] * 1.12))
                occ = e["current"] / max(e["capacity"], 1)
                e["occupancy"] = round(100 * occ, 1)
                e["growth"] = z["growth_rate"] if z else 0
                if occ >= 0.95:
                    e["risk"] = "CRITICAL"
                elif occ >= 0.78 or e["predicted_peak"] > e["capacity"]:
                    e["risk"] = "HIGH"
                elif occ >= 0.55:
                    e["risk"] = "MEDIUM"
                else:
                    e["risk"] = "LOW"
                if z:
                    z["event"] = e["name"] if e["status"] == "LIVE" else z.get("event")
                    z["risk"] = e["risk"]

            # Environment drift
            env = self.state["environment"]
            if "weather" not in self._active_scenarios:
                env["temperature_c"] = round(_clamp(env["temperature_c"] + rng.uniform(-0.08, 0.08), 26, 38), 1)
            else:
                env["temperature_c"] = round(_clamp(env["temperature_c"] - 0.05, 22, 36), 1)

            # Resources
            if "technova" in self._active_scenarios:
                self.state["resources"]["electricity"]["value"] = round(
                    4280 + 900 * self._active_scenarios["technova"]["intensity"], 0
                )
                if self.state["resources"]["electricity"]["value"] > 5000:
                    self.state["resources"]["electricity"]["status"] = "ANOMALY"
                self.state["resources"]["event_facilities"]["value"] = 3

            # Cameras follow zones
            for c in self.state["cameras"]:
                if c["status"] != "ONLINE":
                    continue
                z = self.state["zones"].get(c["zone_code"])
                c["people"] = z["people"] if z else c["people"]
                c["fps"] = round(_clamp(c["fps"] + rng.uniform(-0.3, 0.3), 12, 28), 1)
                c["last_update"] = _now().isoformat()
                if c["zone_code"].startswith("parking") or c["zone_code"] in ("main_gate", "east_gate", "road_central"):
                    c["vehicles"] = int(_clamp(c.get("vehicles", 8) + rng.randint(-2, 3), 0, 60))
                c["detections"] = self._fake_detections(c)

            # Intensify scenarios over time
            for sc in self._active_scenarios.values():
                sc["t"] = sc.get("t", 0) + 1
            if "technova" in self._active_scenarios:
                self._active_scenarios["technova"]["intensity"] = _clamp(
                    self._active_scenarios["technova"]["intensity"] + 0.025, 0, 1.0
                )

            self.state["population"] = int(sum(z["people"] for z in self.state["zones"].values()))
            self.state["updated_at"] = _now().isoformat()
            self._recompute()

            if self.tick % 15 == 0:
                self._persist_snapshot()

            snap = self.snapshot()
            self.history.append(
                {
                    "t": self.state["updated_at"],
                    "tick": self.tick,
                    "population": self.state["population"],
                    "risk": self.state["risk"]["score"],
                    "parking": self._parking_occ(),
                    "auditorium": self.state["zones"]["auditorium"]["people"],
                    "plaza": self.state["zones"]["plaza"]["people"],
                    "main_gate_in": self.state["gates"]["main_gate"]["incoming"],
                }
            )
            if len(self.history) > 1800:
                self.history = self.history[-1200:]
            return snap

    def _advance_demo(self):
        elapsed = time.time() - getattr(self, "_demo_t0", time.time())
        # Scripted hackathon sequence ~90s
        if elapsed > 8 and "technova" not in self._active_scenarios:
            self._active_scenarios["technova"] = {"t": 0, "intensity": 0.2}
            self.state["mode"] = "event"
            self.state["demo_phase"] = "crowd_growth"
        if elapsed > 22 and "parking" not in self._active_scenarios:
            self._active_scenarios["parking"] = {"t": 0, "target": 0.9}
            self.state["demo_phase"] = "parking_pressure"
        if elapsed > 38 and "vehicles" not in self._active_scenarios:
            self._active_scenarios["vehicles"] = {"t": 0, "mult": 1.35}
            self.state["demo_phase"] = "traffic_build"
        if elapsed > 55:
            self.state["demo_phase"] = "risk_elevated"
        if elapsed > 90:
            self._demo_auto = False
            self.state["demo_phase"] = "stable_elevated"

    def _fake_detections(self, cam: dict) -> list:
        dets = []
        n = min(18, int(cam.get("people", 0) / 40) + 2)
        for i in range(n):
            dets.append(
                {
                    "cls": "person",
                    "conf": round(random.uniform(0.62, 0.97), 2),
                    "x": round(random.uniform(0.05, 0.9), 3),
                    "y": round(random.uniform(0.1, 0.85), 3),
                    "w": round(random.uniform(0.03, 0.08), 3),
                    "h": round(random.uniform(0.08, 0.18), 3),
                }
            )
        if cam.get("vehicles", 0) > 0:
            for i in range(min(8, cam["vehicles"] // 3 + 1)):
                dets.append(
                    {
                        "cls": "vehicle",
                        "conf": round(random.uniform(0.7, 0.96), 2),
                        "x": round(random.uniform(0.05, 0.85), 3),
                        "y": round(random.uniform(0.4, 0.85), 3),
                        "w": round(random.uniform(0.08, 0.16), 3),
                        "h": round(random.uniform(0.06, 0.12), 3),
                    }
                )
        return dets

    # ------------------------------------------------------------------ intelligence
    def _parking_occ(self) -> float:
        tot = sum(p["total"] for p in self.state["parking"].values())
        occ = sum(p["occupied"] for p in self.state["parking"].values())
        return round(100 * occ / max(tot, 1), 1)

    def _recompute(self):
        anomalies = []
        alerts_keep = [a for a in self.state["alerts"] if a.get("sticky")]
        # Crowd anomalies
        for z in self.state["zones"].values():
            typical = z["capacity"] * 0.28
            if z["code"] == "auditorium":
                typical = 280
            if z["code"] == "plaza":
                typical = 350
            if z["kind"] == "gate":
                typical = 90
            if z["kind"] == "restricted":
                typical = 12
            if z["people"] > typical * 1.85 and z["people"] > 40:
                anomalies.append(
                    {
                        "kind": "CROWD",
                        "location": z["name"],
                        "zone": z["code"],
                        "severity": "HIGH" if z["people"] > typical * 2.4 else "MEDIUM",
                        "message": f"Unusual crowd concentration detected at {z['name']}.",
                        "detail": f"Current {z['people']} vs normal envelope ~{int(typical * 0.7)}–{int(typical * 1.2)}.",
                    }
                )
            z["risk"] = "HIGH" if z["density"] in ("HIGH", "CRITICAL") else z.get("risk", "LOW")
            if z["density"] == "CRITICAL":
                z["risk"] = "CRITICAL"

        # Parking anomalies
        for p in self.state["parking"].values():
            lo, hi = p["typical_range"]
            if p["occupied"] > hi * 1.15 or p["occupancy"] >= 88:
                anomalies.append(
                    {
                        "kind": "PARKING",
                        "location": p["name"],
                        "zone": p["code"],
                        "severity": "HIGH" if p["occupancy"] >= 92 else "MEDIUM",
                        "message": f"Parking occupancy significantly above the normal historical range.",
                        "detail": f"{p['name']} is {p['occupancy']}% (normal {int(100*lo/p['total'])}–{int(100*hi/p['total'])}%).",
                    }
                )

        # Gate / traffic
        for g in self.state["gates"].values():
            if g["status"] == "CLOSED":
                anomalies.append(
                    {
                        "kind": "TRAFFIC",
                        "location": g["name"],
                        "zone": g["code"],
                        "severity": "HIGH",
                        "message": f"{g['name']} is closed — traffic is redistributing.",
                        "detail": "Remaining gates will absorb inbound flow.",
                    }
                )
            elif g["incoming"] > 140:
                anomalies.append(
                    {
                        "kind": "TRAFFIC",
                        "location": g["name"],
                        "zone": g["code"],
                        "severity": "MEDIUM",
                        "message": f"Inbound flow at {g['name']} is {int((g['incoming']/80-1)*100)}% above typical.",
                        "detail": f"Incoming {g['incoming']}/min, outgoing {g['outgoing']}/min.",
                    }
                )

        # Resource
        for key, r in self.state["resources"].items():
            if r["baseline"] and r["value"] > r["baseline"] * 1.18:
                r["status"] = "ANOMALY"
                anomalies.append(
                    {
                        "kind": "RESOURCE",
                        "location": r["name"],
                        "zone": key,
                        "severity": "MEDIUM",
                        "message": f"{r['name']} consumption anomaly detected.",
                        "detail": f"Current {r['value']} {r['unit']} vs baseline {r['baseline']}.",
                    }
                )
            elif r["status"] != "ANOMALY":
                r["status"] = "NORMAL"

        # Weather + outdoor event
        env = self.state["environment"]
        outdoor_live = any(e["status"] == "LIVE" and e["venue_code"] in ("sports", "lawn") for e in self.state["events"])
        if env["rain_mm"] >= 8 and (outdoor_live or self.state["zones"]["lawn"]["people"] > 200):
            anomalies.append(
                {
                    "kind": "ENVIRONMENT",
                    "location": "Outdoor venues",
                    "zone": "lawn",
                    "severity": "HIGH",
                    "message": "Event disruption risk detected — rain vs outdoor gathering.",
                    "detail": f"{env['condition']} with {env['rain_mm']} mm rain and high outdoor occupancy.",
                }
            )

        self.state["anomalies"] = anomalies[-12:]

        # Predictions
        predictions = []
        # Crowd
        aud = self.state["zones"]["auditorium"]
        growth = max(aud["growth_rate"], 0)
        pred_20 = int(aud["people"] + growth * 2.0)
        pred_30 = int(aud["people"] + growth * 3.0)
        predictions.append(
            {
                "kind": "CROWD",
                "target": "Auditorium",
                "current": aud["people"],
                "predicted": pred_30,
                "horizon_min": 30,
                "confidence": 0.84,
                "label": "Crowd congestion",
                "recommendation": (
                    "Open additional east exit and hold overflow in Central Plaza."
                    if pred_30 > 1100
                    else "Continue monitoring auditorium exits."
                ),
            }
        )
        # Parking A
        pa = self.state["parking"]["parking_a"]
        mins_to_full = None
        if pa["growth_per_10m"] > 0 and pa["available"] > 0:
            mins_to_full = int(10 * pa["available"] / max(pa["growth_per_10m"], 0.1))
        pred_park = _clamp(pa["occupancy"] + max(pa["growth_per_10m"], 0) * 3, 0, 100)
        predictions.append(
            {
                "kind": "PARKING",
                "target": "Parking Zone A",
                "current": pa["occupancy"],
                "predicted": round(pred_park, 1),
                "horizon_min": 30,
                "confidence": 0.81,
                "mins_to_capacity": mins_to_full,
                "label": "Parking shortage",
                "recommendation": (
                    f"Parking Zone A is likely to reach capacity within {mins_to_full} minutes. Redirect incoming vehicles toward Parking Zone C."
                    if mins_to_full and mins_to_full < 40
                    else "Parking demand is within manageable bounds."
                ),
            }
        )
        # Traffic
        gin = self.state["gates"]["main_gate"]["incoming"]
        predictions.append(
            {
                "kind": "TRAFFIC",
                "target": "Main Gate",
                "current": gin,
                "predicted": int(gin * 1.25 + (40 if "technova" in self._active_scenarios else 0)),
                "horizon_min": 20,
                "confidence": 0.78,
                "label": "Traffic buildup",
                "recommendation": (
                    "Activate alternate route via East Gate."
                    if gin > 110
                    else "Main Gate flow is moderate."
                ),
            }
        )
        # Event
        e1 = self.state["events"][0]
        predictions.append(
            {
                "kind": "EVENT",
                "target": e1["name"],
                "current": e1["current"],
                "predicted": e1["predicted_peak"],
                "horizon_min": 40,
                "confidence": 0.8,
                "label": "Event overcrowding",
                "recommendation": (
                    "Expected crowd is likely to exceed venue comfort capacity. Open Plaza overflow and delay inbound tours."
                    if e1["predicted_peak"] > e1["capacity"] * 0.9
                    else "Event load is within venue capacity."
                ),
            }
        )
        self.state["predictions"] = predictions

        # Risk engine
        crowd_c = 0
        park_c = 0
        traffic_c = 0
        event_c = 0
        weather_c = 0
        restr_c = 0
        res_c = 0

        dens_high = sum(1 for z in self.state["zones"].values() if z["density"] in ("HIGH", "CRITICAL"))
        crowd_c = _clamp(dens_high * 7 + aud["people"] / 60, 0, 28)
        park_c = _clamp((self._parking_occ() - 55) * 0.7, 0, 22)
        avg_in = sum(g["incoming"] for g in self.state["gates"].values()) / 3
        traffic_c = _clamp((avg_in - 40) * 0.18, 0, 18)
        if any(e["risk"] in ("HIGH", "CRITICAL") for e in self.state["events"]):
            event_c = 14
        elif any(e["status"] == "LIVE" for e in self.state["events"]):
            event_c = 8
        if env["rain_mm"] >= 8:
            weather_c = 12
        elif env["condition"] != "Clear":
            weather_c = 6
        if self.state["zones"]["restricted"]["people"] > 25:
            restr_c = 16
        if any(r["status"] == "ANOMALY" for r in self.state["resources"].values()):
            res_c = 8
        if any(g["status"] == "CLOSED" for g in self.state["gates"].values()):
            traffic_c = _clamp(traffic_c + 10, 0, 22)

        score = int(_clamp(crowd_c + park_c + traffic_c + event_c + weather_c + restr_c + res_c, 0, 100))
        contributors = [
            {"key": "Crowd density", "value": round(crowd_c, 1), "weight": 25},
            {"key": "Parking pressure", "value": round(park_c, 1), "weight": 18},
            {"key": "Traffic", "value": round(traffic_c, 1), "weight": 14},
            {"key": "Events", "value": round(event_c, 1), "weight": 14},
            {"key": "Weather", "value": round(weather_c, 1), "weight": 10},
            {"key": "Restricted-zone activity", "value": round(restr_c, 1), "weight": 12},
            {"key": "Resource anomalies", "value": round(res_c, 1), "weight": 7},
        ]
        contributors = sorted(contributors, key=lambda x: -x["value"])
        reasons = []
        if aud["people"] > 400:
            reasons.append(f"Auditorium crowd is {int((aud['people']/280 - 1)*100)}% above a quiet-day baseline")
        if pa["occupancy"] >= 85:
            reasons.append(f"Parking Zone A is {pa['occupancy']}% occupied")
        eg = self.state["gates"]["east_gate"]
        if eg["incoming"] > 80:
            reasons.append(f"Traffic near East Gate increased significantly (inbound {eg['incoming']}/min)")
        if self.state["gates"]["main_gate"]["incoming"] > 120:
            reasons.append(f"Main Gate inbound is {self.state['gates']['main_gate']['incoming']}/min")
        if env["rain_mm"] >= 8:
            reasons.append("Rain is active / predicted against outdoor occupancy")
        if self.state["zones"]["restricted"]["people"] > 25:
            reasons.append("Restricted-zone movement is above the normal envelope")
        if not reasons:
            reasons.append("All major subsystems are inside historical envelopes")

        rec = "Continue standard monitoring."
        if score >= 80:
            rec = "Activate campus incident protocol. Freeze inbound visitor parking and staff all gates."
        elif score >= 60:
            rec = "Redirect incoming vehicles, monitor the auditorium exit, and open Plaza overflow."
        elif score >= 35:
            rec = "Increase patrol frequency at Main Gate and Parking A. Prepare overflow signage."

        self.state["risk"] = {
            "score": score,
            "level": _level_from_score(score),
            "status": _status_from_score(score),
            "contributors": contributors,
            "reasons": reasons,
            "recommended_action": rec,
        }

        # Headline
        if score >= 60:
            self.state["headline"] = f"Elevated campus risk ({score}/100). {reasons[0]}."
        elif self.state["mode"] == "event":
            self.state["headline"] = f"TECHNOVA is live — auditorium {aud['people']} and climbing."
        else:
            self.state["headline"] = "Campus operating normally. Digital twin in sync."

        # Promote fresh anomalies to alerts (dedup by type+location)
        existing = {(a["alert_type"], a["location"]) for a in self.state["alerts"]}
        for an in anomalies:
            key = (an["kind"], an["location"])
            mapped = {
                "CROWD": "HIGH CROWD DENSITY",
                "PARKING": "PARKING CAPACITY PREDICTED",
                "TRAFFIC": "TRAFFIC CONGESTION PREDICTED",
                "RESOURCE": "UNUSUAL RESOURCE CONSUMPTION",
                "ENVIRONMENT": "ENVIRONMENTAL RISK",
            }.get(an["kind"], "UNUSUAL CAMPUS ACTIVITY")
            if (mapped, an["location"]) in existing:
                continue
            if an["severity"] in ("HIGH", "CRITICAL") or (an["severity"] == "MEDIUM" and self.tick % 5 == 0):
                self._note_alert(
                    mapped,
                    an["location"],
                    an["severity"],
                    an["message"] + " " + an["detail"],
                    "",
                    rec,
                )
                existing.add((mapped, an["location"]))

        self.state["alerts"] = self.state["alerts"][:40]

    def _note_alert(self, typ, location, severity, reason, prediction, action):
        self.alert_seq += 1
        item = {
            "id": self.alert_seq,
            "alert_type": typ,
            "location": location,
            "severity": severity,
            "reason": reason,
            "prediction": prediction,
            "recommended_action": action,
            "status": "OPEN",
            "time": _now().isoformat(),
            "sticky": severity in ("HIGH", "CRITICAL"),
        }
        self.state["alerts"].insert(0, item)
        try:
            db = SessionLocal()
            db.add(
                Alert(
                    alert_type=typ,
                    location=location,
                    severity=severity,
                    reason=reason,
                    prediction=prediction,
                    recommended_action=action,
                    status="OPEN",
                )
            )
            db.commit()
            db.close()
        except Exception:
            pass

    def snapshot(self) -> dict:
        with LOCK:
            s = deepcopy(self.state)
            s["kpis"] = {
                "population": s["population"],
                "active_cameras": sum(1 for c in s["cameras"] if c["status"] == "ONLINE"),
                "total_cameras": len(s["cameras"]),
                "active_events": sum(1 for e in s["events"] if e["status"] == "LIVE"),
                "open_alerts": sum(1 for a in s["alerts"] if a["status"] == "OPEN"),
                "parking_occupancy": self._parking_occ(),
                "risk_score": s["risk"]["score"],
                "risk_level": s["risk"]["level"],
                "ai_status": s["ai_engine"]["status"],
                "crowd_peak_zone": max(s["zones"].values(), key=lambda z: z["people"])["name"],
                "traffic_status": max(s["gates"].values(), key=lambda g: 0 if g["status"] == "CLOSED" else g["incoming"])[
                    "traffic"
                ],
            }
            return s

    # ------------------------------------------------------------------ persist
    def _persist_snapshot(self):
        try:
            db = SessionLocal()
            s = self.state
            db.add(
                CampusMetric(
                    population=s["population"],
                    crowd_peak_zone=max(s["zones"].values(), key=lambda z: z["people"])["name"],
                    parking_occupancy=self._parking_occ(),
                    traffic_index=sum(g["incoming"] for g in s["gates"].values()),
                    risk_score=s["risk"]["score"],
                    anomaly_count=len(s["anomalies"]),
                )
            )
            for code, z in s["zones"].items():
                db.add(
                    CrowdRecord(
                        zone_code=code,
                        people=z["people"],
                        density=z["density"],
                        growth_rate=z["growth_rate"],
                        direction=z["direction"],
                    )
                )
            for code, p in s["parking"].items():
                db.add(
                    VehicleRecord(
                        zone_code=code,
                        cars=p["cars"],
                        bikes=p["bikes"],
                        other=p["other"],
                        incoming=0,
                        outgoing=0,
                    )
                )
            for g in s["gates"].values():
                db.add(
                    TrafficRecord(
                        route_code=g["code"],
                        volume=g["incoming"] + g["outgoing"],
                        congestion=g["traffic"] if g["traffic"] != "CLOSED" else "HIGH",
                        direction="IN",
                    )
                )
            env = s["environment"]
            db.add(
                EnvironmentalData(
                    temperature_c=env["temperature_c"],
                    humidity=env["humidity"],
                    condition=env["condition"],
                    rain_mm=env["rain_mm"],
                    aqi=env["aqi"],
                    wind_kmh=env["wind_kmh"],
                )
            )
            for key, r in s["resources"].items():
                db.add(ResourceUsage(resource=key, value=r["value"], unit=r["unit"], baseline=r["baseline"]))
            db.commit()
            db.close()
        except Exception:
            pass

    def start(self):
        if self.running:
            return
        self.running = True

        def loop():
            while self.running:
                try:
                    self.step()
                except Exception:
                    pass
                time.sleep(2.0)

        self.thread = threading.Thread(target=loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False


CAMPUS_META = {
    "name": "Nexus Institute of Technology",
    "code": "NIT-HYD",
    "city": "Hyderabad",
    "area_acres": 86,
    "established": 1998,
    "tagline": "Understand the present. Simulate the future. Prevent the unexpected.",
}


engine_singleton = TwinEngine()


def get_twin() -> TwinEngine:
    return engine_singleton
