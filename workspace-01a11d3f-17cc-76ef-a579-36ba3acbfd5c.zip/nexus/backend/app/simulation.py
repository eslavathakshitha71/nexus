"""What-If simulator — clone the twin, apply a hypothetical, project 15/30/60 min."""
from __future__ import annotations

import json
from copy import deepcopy
from datetime import datetime, timezone

from .database import SessionLocal, Simulation
from .twin import get_twin, _clamp, _density, _cong, _level_from_score, _status_from_score


SCENARIOS = [
    {
        "id": "gate_closed",
        "name": "Main Gate Closed",
        "prompt": "What happens if the main gate is closed?",
        "params": [{"key": "gate", "label": "Gate", "type": "select", "options": ["main_gate", "north_gate", "east_gate"], "default": "main_gate"}],
    },
    {
        "id": "event_crowd",
        "name": "Event Attracts a Surge",
        "prompt": "What happens if an event attracts 2,000 people?",
        "params": [{"key": "attendance", "label": "Simulated attendance", "type": "number", "min": 200, "max": 4000, "default": 2000}],
    },
    {
        "id": "parking_offline",
        "name": "Parking Zone Unavailable",
        "prompt": "What happens if Parking Zone A becomes unavailable?",
        "params": [{"key": "zone", "label": "Parking zone", "type": "select", "options": ["parking_a", "parking_b", "parking_c", "parking_2w"], "default": "parking_a"}],
    },
    {
        "id": "event_extended",
        "name": "Event Extended",
        "prompt": "What happens if the event is extended by two hours?",
        "params": [{"key": "extra_hours", "label": "Extra hours", "type": "number", "min": 1, "max": 6, "default": 2}],
    },
    {
        "id": "more_vehicles",
        "name": "Vehicle Inflow +30%",
        "prompt": "What happens if 30% more vehicles arrive?",
        "params": [{"key": "pct", "label": "Increase %", "type": "number", "min": 10, "max": 100, "default": 30}],
    },
    {
        "id": "heavy_rain",
        "name": "Heavy Rain During Event",
        "prompt": "What happens if heavy rain starts during the event?",
        "params": [{"key": "mm", "label": "Rainfall mm", "type": "number", "min": 5, "max": 80, "default": 22}],
    },
    {
        "id": "custom",
        "name": "Custom Mix",
        "prompt": "Combine parameters for a custom hypothetical.",
        "params": [
            {"key": "crowd_mult", "label": "Crowd multiplier", "type": "number", "min": 0.5, "max": 3, "default": 1.4},
            {"key": "vehicle_mult", "label": "Vehicle multiplier", "type": "number", "min": 0.5, "max": 3, "default": 1.2},
        ],
    },
]


def _project(state: dict, minutes: int, mutator) -> dict:
    s = deepcopy(state)
    steps = max(1, minutes // 5)
    for _ in range(steps):
        mutator(s, 5)
    return s


def _risk_of(s: dict) -> dict:
    aud = s["zones"]["auditorium"]["people"]
    park = sum(p["occupied"] for p in s["parking"].values()) / max(sum(p["total"] for p in s["parking"].values()), 1)
    dens_high = sum(1 for z in s["zones"].values() if z["density"] in ("HIGH", "CRITICAL"))
    crowd_c = _clamp(dens_high * 7 + aud / 60, 0, 28)
    park_c = _clamp((park * 100 - 55) * 0.7, 0, 22)
    avg_in = sum(g.get("incoming", 0) for g in s["gates"].values()) / 3
    traffic_c = _clamp((avg_in - 40) * 0.18, 0, 18)
    event_c = 12 if any(e.get("risk") in ("HIGH", "CRITICAL") for e in s["events"]) else 6
    weather_c = 12 if s["environment"].get("rain_mm", 0) >= 8 else 0
    restr_c = 14 if s["zones"]["restricted"]["people"] > 25 else 0
    res_c = 8 if any(r.get("status") == "ANOMALY" for r in s["resources"].values()) else 0
    if any(g.get("status") == "CLOSED" for g in s["gates"].values()):
        traffic_c = _clamp(traffic_c + 10, 0, 22)
    score = int(_clamp(crowd_c + park_c + traffic_c + event_c + weather_c + restr_c + res_c, 0, 100))
    return {
        "score": score,
        "level": _level_from_score(score),
        "status": _status_from_score(score),
        "contributors": [
            {"key": "Crowd density", "value": round(crowd_c, 1)},
            {"key": "Parking pressure", "value": round(park_c, 1)},
            {"key": "Traffic", "value": round(traffic_c, 1)},
            {"key": "Weather", "value": round(weather_c, 1)},
        ],
    }


def run_simulation(scenario: str, params: dict, created_by: str = "admin") -> dict:
    twin = get_twin()
    current = twin.snapshot()
    base = deepcopy(current)

    def mutate_gate(s, dt):
        gate = params.get("gate", "main_gate")
        s["gates"][gate]["status"] = "CLOSED"
        spilled = s["gates"][gate]["incoming"]
        s["gates"][gate]["incoming"] = 0
        s["gates"][gate]["traffic"] = "CLOSED"
        others = [k for k in s["gates"] if k != gate]
        for k in others:
            s["gates"][k]["incoming"] = int(_clamp(s["gates"][k]["incoming"] + spilled / len(others) * 0.35, 0, 320))
            s["gates"][k]["traffic"] = _cong(s["gates"][k]["incoming"] + s["gates"][k]["outgoing"], 220)
        # parking demand +18%
        for p in s["parking"].values():
            extra = int(p["occupied"] * 0.03)
            p["occupied"] = int(_clamp(p["occupied"] + extra, 0, p["total"]))
            p["available"] = p["total"] - p["occupied"]
            p["occupancy"] = round(100 * p["occupied"] / p["total"], 1)
        s["zones"]["east_gate"]["people"] = int(_clamp(s["zones"]["east_gate"]["people"] + 18, 0, s["zones"]["east_gate"]["capacity"]))
        s["zones"]["road_central"]["people"] = int(_clamp(s["zones"]["road_central"]["people"] + 12, 0, 300))
        for z in s["zones"].values():
            z["density"] = _density(z["people"], z["capacity"])

    def mutate_event(s, dt):
        target = int(params.get("attendance", 2000))
        aud = s["zones"]["auditorium"]
        step = max(8, (target - aud["people"]) // 8)
        aud["people"] = int(_clamp(aud["people"] + step, 0, aud["capacity"] * 1.15))
        aud["density"] = _density(aud["people"], aud["capacity"])
        s["zones"]["plaza"]["people"] = int(_clamp(s["zones"]["plaza"]["people"] + step * 0.45, 0, 2000))
        s["zones"]["cafeteria"]["people"] = int(_clamp(s["zones"]["cafeteria"]["people"] + step * 0.2, 0, 700))
        s["gates"]["main_gate"]["incoming"] = int(_clamp(s["gates"]["main_gate"]["incoming"] + 10, 0, 280))
        for p in s["parking"].values():
            p["occupied"] = int(_clamp(p["occupied"] + 4, 0, p["total"]))
            p["available"] = p["total"] - p["occupied"]
            p["occupancy"] = round(100 * p["occupied"] / p["total"], 1)
        s["events"][0]["current"] = int(aud["people"])
        s["events"][0]["predicted_peak"] = target
        s["events"][0]["status"] = "LIVE"
        s["resources"]["electricity"]["value"] = 4280 + (target / 1200) * 1100
        if s["resources"]["electricity"]["value"] > 5000:
            s["resources"]["electricity"]["status"] = "ANOMALY"
        for z in s["zones"].values():
            z["density"] = _density(z["people"], z["capacity"])

    def mutate_parking_off(s, dt):
        zone = params.get("zone", "parking_a")
        displaced = s["parking"][zone]["occupied"]
        s["parking"][zone]["occupied"] = s["parking"][zone]["total"]
        s["parking"][zone]["available"] = 0
        s["parking"][zone]["occupancy"] = 100
        others = [k for k in s["parking"] if k != zone]
        share = displaced // max(len(others), 1)
        for k in others:
            s["parking"][k]["occupied"] = int(_clamp(s["parking"][k]["occupied"] + share * 0.25, 0, s["parking"][k]["total"]))
            s["parking"][k]["available"] = s["parking"][k]["total"] - s["parking"][k]["occupied"]
            s["parking"][k]["occupancy"] = round(100 * s["parking"][k]["occupied"] / s["parking"][k]["total"], 1)
        s["gates"]["east_gate"]["incoming"] = int(_clamp(s["gates"]["east_gate"]["incoming"] + 14, 0, 260))
        s["zones"]["road_central"]["people"] = int(_clamp(s["zones"]["road_central"]["people"] + 16, 0, 300))

    def mutate_extend(s, dt):
        s["resources"]["electricity"]["value"] = s["resources"]["electricity"]["value"] + 80
        s["resources"]["electricity"]["status"] = "ANOMALY" if s["resources"]["electricity"]["value"] > 5000 else s["resources"]["electricity"]["status"]
        s["zones"]["auditorium"]["people"] = int(_clamp(s["zones"]["auditorium"]["people"] * 1.04, 0, 1500))
        s["zones"]["cafeteria"]["people"] = int(_clamp(s["zones"]["cafeteria"]["people"] + 12, 0, 700))
        s["events"][0]["duration_min"] = s["events"][0].get("duration_min", 180) + 10
        for z in s["zones"].values():
            z["density"] = _density(z["people"], z["capacity"])

    def mutate_vehicles(s, dt):
        pct = float(params.get("pct", 30)) / 100.0
        for g in s["gates"].values():
            if g["status"] != "CLOSED":
                g["incoming"] = int(g["incoming"] * (1 + pct * 0.2))
                g["vehicles_in"] = int(g.get("vehicles_in", 10) * (1 + pct * 0.2))
                g["traffic"] = _cong(g["incoming"] + g["outgoing"], 220)
        for p in s["parking"].values():
            p["occupied"] = int(_clamp(p["occupied"] + p["total"] * pct * 0.08, 0, p["total"]))
            p["available"] = p["total"] - p["occupied"]
            p["occupancy"] = round(100 * p["occupied"] / p["total"], 1)
        s["zones"]["road_central"]["people"] = int(_clamp(s["zones"]["road_central"]["people"] + 10, 0, 300))

    def mutate_rain(s, dt):
        s["environment"]["condition"] = "Heavy Rain"
        s["environment"]["rain_mm"] = float(params.get("mm", 22))
        s["environment"]["humidity"] = 90
        # outdoor -> indoor surge
        moved = int(s["zones"]["lawn"]["people"] * 0.45 + s["zones"]["sports"]["people"] * 0.25)
        s["zones"]["lawn"]["people"] = int(s["zones"]["lawn"]["people"] * 0.55)
        s["zones"]["auditorium"]["people"] = int(_clamp(s["zones"]["auditorium"]["people"] + moved * 0.5, 0, 1650))
        s["zones"]["cafeteria"]["people"] = int(_clamp(s["zones"]["cafeteria"]["people"] + moved * 0.25, 0, 700))
        s["zones"]["library"]["people"] = int(_clamp(s["zones"]["library"]["people"] + moved * 0.15, 0, 900))
        s["gates"]["main_gate"]["incoming"] = int(s["gates"]["main_gate"]["incoming"] * 0.72)
        for z in s["zones"].values():
            z["density"] = _density(z["people"], z["capacity"])

    def mutate_custom(s, dt):
        cm = float(params.get("crowd_mult", 1.4))
        vm = float(params.get("vehicle_mult", 1.2))
        for z in s["zones"].values():
            if z["kind"] in ("venue", "open", "amenity", "gate"):
                z["people"] = int(_clamp(z["people"] * (1 + (cm - 1) * 0.15), 0, z["capacity"] * 1.1))
                z["density"] = _density(z["people"], z["capacity"])
        for g in s["gates"].values():
            g["incoming"] = int(g["incoming"] * (1 + (vm - 1) * 0.15))
            g["traffic"] = _cong(g["incoming"] + g["outgoing"], 220)
        for p in s["parking"].values():
            p["occupied"] = int(_clamp(p["occupied"] * (1 + (vm - 1) * 0.12), 0, p["total"]))
            p["available"] = p["total"] - p["occupied"]
            p["occupancy"] = round(100 * p["occupied"] / p["total"], 1)

    mutators = {
        "gate_closed": mutate_gate,
        "event_crowd": mutate_event,
        "parking_offline": mutate_parking_off,
        "event_extended": mutate_extend,
        "more_vehicles": mutate_vehicles,
        "heavy_rain": mutate_rain,
        "custom": mutate_custom,
    }
    mut = mutators.get(scenario, mutate_custom)

    t15 = _project(base, 15, mut)
    t30 = _project(base, 30, mut)
    t60 = _project(base, 60, mut)
    for s in (t15, t30, t60):
        s["risk"] = _risk_of(s)
        s["population"] = int(sum(z["people"] for z in s["zones"].values()))

    future = t30
    impacts = _impacts(current, future)
    recs = _recommendations(scenario, current, future, impacts)

    result = {
        "scenario": scenario,
        "params": params,
        "ran_at": datetime.now(timezone.utc).isoformat(),
        "current": _slim(current),
        "t15": _slim(t15),
        "t30": _slim(t30),
        "t60": _slim(t60),
        "impacts": impacts,
        "recommendations": recs,
        "narrative": _narrative(scenario, current, future, recs),
        "comparison": {
            "population": [current["population"], future["population"]],
            "risk": [current["risk"]["score"], future["risk"]["score"]],
            "parking": [
                round(sum(p["occupancy"] * p["total"] for p in current["parking"].values()) / max(sum(p["total"] for p in current["parking"].values()), 1), 1),
                round(sum(p["occupancy"] * p["total"] for p in future["parking"].values()) / max(sum(p["total"] for p in future["parking"].values()), 1), 1),
            ],
            "auditorium": [current["zones"]["auditorium"]["people"], future["zones"]["auditorium"]["people"]],
            "main_gate_in": [current["gates"]["main_gate"]["incoming"], future["gates"]["main_gate"]["incoming"]],
            "east_gate_in": [current["gates"]["east_gate"]["incoming"], future["gates"]["east_gate"]["incoming"]],
        },
    }

    try:
        db = SessionLocal()
        db.add(
            Simulation(
                name=scenario,
                scenario=scenario,
                parameters=json.dumps(params),
                result=json.dumps({k: result[k] for k in ("impacts", "recommendations", "comparison")}),
                created_by=created_by,
            )
        )
        db.commit()
        db.close()
    except Exception:
        pass
    return result


def _slim(s: dict) -> dict:
    return {
        "population": s.get("population"),
        "risk": s.get("risk"),
        "zones": {
            k: {"people": v["people"], "density": v["density"], "name": v["name"], "capacity": v["capacity"]}
            for k, v in s["zones"].items()
        },
        "parking": {
            k: {"occupancy": v["occupancy"], "occupied": v["occupied"], "available": v["available"], "total": v["total"], "name": v["name"]}
            for k, v in s["parking"].items()
        },
        "gates": s["gates"],
        "events": s["events"],
        "environment": s["environment"],
        "resources": s["resources"],
    }


def _impacts(cur, fut) -> list:
    items = []
    def delta(label, a, b, unit=""):
        items.append({"label": label, "from": a, "to": b, "delta": round(b - a, 1), "unit": unit})
    delta("Campus population", cur["population"], fut["population"], "people")
    delta("Risk score", cur["risk"]["score"], fut["risk"]["score"], "/100")
    delta("Auditorium crowd", cur["zones"]["auditorium"]["people"], fut["zones"]["auditorium"]["people"], "people")
    delta("Plaza crowd", cur["zones"]["plaza"]["people"], fut["zones"]["plaza"]["people"], "people")
    delta("Main Gate inbound", cur["gates"]["main_gate"]["incoming"], fut["gates"]["main_gate"]["incoming"], "/min")
    delta("East Gate inbound", cur["gates"]["east_gate"]["incoming"], fut["gates"]["east_gate"]["incoming"], "/min")
    delta("North Gate inbound", cur["gates"]["north_gate"]["incoming"], fut["gates"]["north_gate"]["incoming"], "/min")
    for k in cur["parking"]:
        delta(cur["parking"][k]["name"] + " occupancy", cur["parking"][k]["occupancy"], fut["parking"][k]["occupancy"], "%")
    delta("Electricity", cur["resources"]["electricity"]["value"], fut["resources"]["electricity"]["value"], "kWh")
    return items


def _recommendations(scenario, cur, fut, impacts) -> list:
    recs = []
    if scenario == "gate_closed":
        recs = [
            "Open East Gate express lane and staff North Gate with an additional marshal.",
            "Redirect approximately 35% of incoming traffic toward Gate 3 (East).",
            "Publish a live parking map pushing visitors to Zone C.",
            "Hold bus drop-offs at the Transport Hub instead of Main Gate.",
        ]
        if fut["gates"]["east_gate"]["incoming"] > 140:
            recs.append("East Gate congestion predicted HIGH — split inbound 60/40 East/North.")
    elif scenario == "event_crowd":
        recs = [
            "Open Central Plaza as a holding/overflow zone with shade and water.",
            "Stagger entry waves of 250 people every 8 minutes.",
            "Unlock the auditorium east and north exits; keep inbound on the south.",
            "Pre-position medical and volunteer staff at density hotspots.",
        ]
        if fut["zones"]["auditorium"]["people"] > fut["zones"]["auditorium"]["capacity"] * 0.9:
            recs.append("Predicted occupancy exceeds comfort capacity — cap walk-ins and stream the keynote to the lawn screen.")
    elif scenario == "parking_offline":
        recs = [
            "Activate Parking Zone C as the primary visitor sink.",
            "Stand up a shuttle loop from two-wheeler parking to the auditorium.",
            "Place digital signage at East Gate 400m out.",
        ]
    elif scenario == "event_extended":
        recs = [
            "Extend shuttle service by the same two hours.",
            "Notify facilities of the electricity anomaly envelope.",
            "Keep cafeteria staffing on the late-night roster.",
        ]
    elif scenario == "more_vehicles":
        recs = [
            "Turn on the one-way inner loop around Central Road.",
            "Redirect inbound four-wheelers toward Parking Zone C.",
            "Prioritize two-wheeler slots near Academic Block B to free 4W capacity.",
        ]
    elif scenario == "heavy_rain":
        recs = [
            "Move outdoor overflow to the Auditorium and Library reading halls.",
            "Cover walkways from Parking A to the Auditorium.",
            "Delay the sports fixture or move spectators under the indoor gallery.",
            "Issue a campus-wide weather advisory via the public address twin.",
        ]
    else:
        recs = ["Rebalance inbound gates", "Open overflow zones", "Brief security on the simulated hotspots"]
    recs.append("Do not identify individuals — continue anonymous density and flow analytics only.")
    return recs


def _narrative(scenario, cur, fut, recs) -> str:
    titles = {s["id"]: s["name"] for s in SCENARIOS}
    return (
        f"Simulation: {titles.get(scenario, scenario)}. "
        f"Campus risk moves from {cur['risk']['score']} to {fut['risk']['score']}/100 in 30 minutes. "
        f"Auditorium crowd {cur['zones']['auditorium']['people']} → {fut['zones']['auditorium']['people']}. "
        f"Primary action: {recs[0]}"
    )
