"""NEXUS Decision Assistant — answers from live twin state (explainable, no identity)."""
from __future__ import annotations

import re
from datetime import datetime, timezone

from .simulation import run_simulation
from .twin import get_twin


def _top_crowd(s):
    z = max(s["zones"].values(), key=lambda x: x["people"])
    return z


def _first_full_parking(s):
    ranked = sorted(s["parking"].values(), key=lambda p: -p["occupancy"])
    return ranked[0]


def answer(question: str) -> dict:
    q = (question or "").strip()
    ql = q.lower()
    s = get_twin().snapshot()
    risk = s["risk"]
    top = _top_crowd(s)
    park = _first_full_parking(s)

    def pack(title, body, extras=None):
        return {
            "question": q,
            "title": title,
            "answer": body,
            "risk": risk,
            "citations": extras or [],
            "ts": datetime.now(timezone.utc).isoformat(),
        }

    if re.search(r"how is the campus|status right now|right now|overview|situation", ql):
        body = (
            f"Campus status is **{risk['level']}** with a fused risk score of **{risk['score']}/100**. "
            f"Live population is **{s['population']:,}** anonymous occupants. "
            f"Highest concentration: **{top['name']} ({top['people']} people, {top['density']} density)**. "
            f"Parking network is at **{s['kpis']['parking_occupancy']}%**. "
            f"{s['kpis']['active_events']} live event(s), {s['kpis']['open_alerts']} open alerts. "
            f"AI engine is {s['ai_engine']['status']} with anonymization ON.\n\n"
            f"Why this score: " + "; ".join(risk["reasons"]) + ".\n\n"
            f"Recommended action: {risk['recommended_action']}"
        )
        return pack("Campus now", body)

    if re.search(r"highest crowd|where is the crowd|concentration|busiest", ql):
        ranked = sorted(s["zones"].values(), key=lambda z: -z["people"])[:5]
        lines = "\n".join(f"• {z['name']}: {z['people']} ({z['density']}, growth {z['growth_rate']:+.0f}/tick)" for z in ranked)
        body = (
            f"Highest crowd concentration is **{top['name']}** at **{top['people']} people** "
            f"({top['density']} density, capacity {top['capacity']}).\n\n{lines}"
        )
        return pack("Crowd hotspots", body)

    if re.search(r"parking.*fill|which parking|parking zone", ql):
        preds = [p for p in s["predictions"] if p["kind"] == "PARKING"]
        extra = preds[0]["recommendation"] if preds else ""
        ranked = sorted(s["parking"].values(), key=lambda p: -p["occupancy"])
        lines = "\n".join(
            f"• {p['name']}: {p['occupancy']}% ({p['occupied']}/{p['total']}, {p['available']} free, {p['growth_per_10m']:+.1f}/10min)"
            for p in ranked
        )
        body = (
            f"**{park['name']}** will fill first — currently **{park['occupancy']}%** with "
            f"{park['available']} bays left.\n\n{lines}\n\n{extra}"
        )
        return pack("Parking intelligence", body)

    if re.search(r"unusual|anomal|anything wrong|incident", ql):
        if not s["anomalies"]:
            return pack("Anomalies", "No material anomalies versus the learned historical envelope. Campus is inside normal bands.")
        lines = "\n".join(f"• **{a['severity']}** — {a['message']} {a['detail']}" for a in s["anomalies"][:8])
        return pack("Unusual activity", f"{len(s['anomalies'])} anomaly signal(s):\n\n{lines}")

    if re.search(r"gate 1|main gate.*closed|if the main gate|close the gate", ql):
        sim = run_simulation("gate_closed", {"gate": "main_gate"})
        body = sim["narrative"] + "\n\n" + "\n".join(f"• {r}" for r in sim["recommendations"])
        return pack("What-if: Main Gate closed", body, ["simulation:gate_closed"])

    if re.search(r"what could happen if|what happens if|simulate|what-if|what if", ql):
        if "rain" in ql:
            sim = run_simulation("heavy_rain", {"mm": 22})
        elif "2000" in ql or "2,000" in ql or "event" in ql:
            sim = run_simulation("event_crowd", {"attendance": 2000})
        elif "parking" in ql:
            sim = run_simulation("parking_offline", {"zone": "parking_a"})
        elif "vehicle" in ql:
            sim = run_simulation("more_vehicles", {"pct": 30})
        else:
            sim = run_simulation("gate_closed", {"gate": "main_gate"})
        body = sim["narrative"] + "\n\n" + "\n".join(f"• {r}" for r in sim["recommendations"])
        return pack("Simulation", body)

    if re.search(r"biggest.*risk|operational risk|why.*risk|risk score", ql):
        contrib = "\n".join(f"• {c['key']}: +{c['value']}" for c in risk["contributors"] if c["value"] > 0)
        body = (
            f"Campus risk score is **{risk['score']}/100 ({risk['level']})**.\n\n"
            f"Main contributors:\n{contrib}\n\n"
            f"Reasons:\n" + "\n".join(f"• {r}" for r in risk["reasons"]) + "\n\n"
            f"Recommended action: {risk['recommended_action']}"
        )
        return pack("Risk explained", body)

    if re.search(r"event.*congest|which event|technova|events", ql):
        lines = []
        for e in s["events"]:
            lines.append(
                f"• **{e['name']}** @ {e['venue']} — {e['current']}/{e['capacity']} "
                f"(expected {e['expected']}, predicted peak {e['predicted_peak']}, risk {e['risk']}, {e['status']})"
            )
        return pack("Event intelligence", "Live event picture:\n\n" + "\n".join(lines))

    if re.search(r"weather|rain|environment", ql):
        env = s["environment"]
        body = (
            f"{env['condition']}, {env['temperature_c']}°C, humidity {env['humidity']}%, "
            f"AQI {env['aqi']}, wind {env['wind_kmh']} km/h, rain {env['rain_mm']} mm.\n"
            f"Forecast: {env['forecast']}"
        )
        return pack("Environment", body)

    if re.search(r"recommend|what should we do|action", ql):
        return pack("Recommended actions", risk["recommended_action"] + "\n\nOpen alerts:\n" + "\n".join(
            f"• {a['alert_type']} @ {a['location']}: {a['recommended_action']}" for a in s["alerts"][:5]
        ))

    if re.search(r"privacy|facial|identity|tracking", ql):
        p = s["privacy"]
        return pack(
            "Privacy posture",
            f"Facial recognition: {'ON' if p['facial_recognition'] else 'OFF (default)'}. "
            f"Identity tracking: {'ON' if p['identity_tracking'] else 'OFF'}. "
            f"Anonymous analytics only: {p['anonymous_analytics_only']}. "
            f"Retention: {p['data_retention_days']} days. Raw video storage: {p['store_raw_video']}. "
            f"NEXUS counts people and vehicles — it does not identify students.",
        )

    # default
    body = (
        f"I read the live twin at risk {risk['score']}/100 ({risk['level']}). "
        f"Hotspot {top['name']} ({top['people']}). Parking leader {park['name']} at {park['occupancy']}%. "
        f"{risk['recommended_action']}\n\n"
        f"Ask me about crowd, parking, anomalies, risk, events, weather, or run a what-if."
    )
    return pack("NEXUS", body)


def daily_briefing() -> dict:
    s = get_twin().snapshot()
    hist = get_twin().history
    peak_pop = max([h["population"] for h in hist], default=s["population"])
    peak_park = max([h["parking"] for h in hist], default=s["kpis"]["parking_occupancy"])
    peak_aud = max([h["auditorium"] for h in hist], default=s["zones"]["auditorium"]["people"])
    anomalies = len(s["anomalies"])
    events = [e for e in s["events"] if e["status"] in ("LIVE", "SCHEDULED")]
    summary = (
        f"Campus activity remained {'elevated' if s['risk']['score'] >= 35 else 'normal'} through this window. "
        f"A {'major' if peak_aud > 600 else 'moderate'} crowd increase occurred around the auditorium "
        f"(peak {peak_aud}). Parking demand "
        f"{'exceeded the historical average' if peak_park > 80 else 'stayed near typical levels'} "
        f"(peak {peak_park}%). "
        f"{'No critical safety anomaly was detected.' if s['risk']['score'] < 80 else 'Critical fused risk was raised — see contributors.'} "
        f"All analytics remain anonymous: no facial recognition, no identity tracking."
    )
    return {
        "title": "TODAY'S CAMPUS INTELLIGENCE",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "peak_population": int(peak_pop),
        "peak_crowd_zone": s["kpis"]["crowd_peak_zone"],
        "peak_auditorium": int(peak_aud),
        "parking_peak": peak_park,
        "major_anomalies": anomalies,
        "major_events": len(events),
        "predicted_risks": sum(1 for p in s["predictions"] if p["predicted"] > p["current"] * 1.15),
        "risk": s["risk"],
        "events": events,
        "summary": summary,
        "timeline": _timeline(s, hist),
        "privacy_note": "This briefing is produced from anonymous counts, densities, and resource telemetry only.",
    }


def _timeline(s, hist):
    if not hist:
        return [
            {"t": "Now", "text": s["headline"]},
        ]
    # downsample
    pts = hist[:: max(1, len(hist) // 8)][-8:]
    out = []
    for h in pts:
        out.append(
            {
                "t": h["t"][11:16] if isinstance(h["t"], str) and len(h["t"]) > 16 else str(h["tick"]),
                "text": f"Population {h['population']:,} · risk {h['risk']} · parking {h['parking']}% · auditorium {h['auditorium']}",
            }
        )
    return out
