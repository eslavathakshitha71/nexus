"""Seed users, campus graph, cameras, historical telemetry."""
from __future__ import annotations

import math
import random
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from .auth import hash_password
from .database import (
    Alert,
    Building,
    Camera,
    CampusEvent,
    CampusMetric,
    CrowdRecord,
    EnvironmentalData,
    ParkingSlot,
    ParkingZone,
    PrivacySetting,
    ResourceUsage,
    TrafficRecord,
    User,
    VehicleRecord,
    Zone,
)
from .twin import CAMERA_DEFS, PARKING_DEFS, ZONE_DEFS


DEMO_USERS = [
    dict(username="superadmin", full_name="Aanya Rao", email="aanya.rao@nexus.campus", role="SUPER_ADMIN", password="Nexus@2026"),
    dict(username="campusadmin", full_name="Vikram Shah", email="vikram.shah@nexus.campus", role="CAMPUS_ADMIN", password="Campus@2026"),
    dict(username="security", full_name="Meera Iyer", email="meera.iyer@nexus.campus", role="SECURITY_ADMIN", password="Secure@2026"),
    dict(username="eventadmin", full_name="Rahul Nair", email="rahul.nair@nexus.campus", role="EVENT_ADMIN", password="Event@2026"),
]


def seed_if_empty(db: Session):
    if db.query(User).count() > 0:
        return
    for u in DEMO_USERS:
        db.add(
            User(
                username=u["username"],
                full_name=u["full_name"],
                email=u["email"],
                role=u["role"],
                hashed_password=hash_password(u["password"]),
                is_active=True,
            )
        )

    for z in ZONE_DEFS:
        db.add(
            Building(
                code=z["code"],
                name=z["name"],
                kind=z["kind"],
                capacity=z["capacity"],
                x=z["x"],
                y=z["y"],
                w=z["w"],
                h=z["h"],
                restricted=z["kind"] == "restricted",
            )
        )
        db.add(
            Zone(
                code=z["code"],
                name=z["name"],
                kind=z["kind"],
                capacity=z["capacity"],
                x=z["x"],
                y=z["y"],
                w=z["w"],
                h=z["h"],
            )
        )

    for c in CAMERA_DEFS:
        db.add(
            Camera(
                camera_id=c["id"],
                name=c["name"],
                location=c["location"],
                zone_code=c["zone"],
                status="ONLINE",
                ai_status="ACTIVE",
                fps=c["fps"],
                source_type="DEMO",
            )
        )

    for p in PARKING_DEFS:
        db.add(ParkingZone(code=p["code"], name=p["name"], category=p["category"], total_slots=p["total"], occupied=int(p["total"] * p["typical"])))
        for i in range(min(p["total"], 40)):
            db.add(
                ParkingSlot(
                    zone_code=p["code"],
                    slot_code=f"{p['code'][-1].upper()}-{i+1:03d}",
                    occupied=i < int(40 * p["typical"]),
                    vehicle_type="BIKE" if p["category"] == "TWO_WHEELER" else "CAR",
                )
            )

    now = datetime.now(timezone.utc)
    db.add(
        CampusEvent(
            name="TECHNOVA 2026",
            venue_code="auditorium",
            expected_attendance=1200,
            current_crowd=180,
            capacity=1500,
            risk_level="LOW",
            status="SCHEDULED",
            starts_at=now + timedelta(minutes=40),
            ends_at=now + timedelta(hours=4),
            description="Annual technology festival — keynotes, expo, hackathon showcase.",
        )
    )
    db.add(
        CampusEvent(
            name="Inter-College Football Finals",
            venue_code="sports",
            expected_attendance=420,
            current_crowd=210,
            capacity=800,
            risk_level="LOW",
            status="LIVE",
            starts_at=now - timedelta(minutes=20),
            ends_at=now + timedelta(hours=1, minutes=30),
            description="Championship match.",
        )
    )

    db.add(
        PrivacySetting(
            facial_recognition=False,
            identity_tracking=False,
            anonymous_analytics_only=True,
            data_retention_days=30,
            store_raw_video=False,
            audit_logging=True,
        )
    )

    rng = random.Random(7)
    # 7 days of hourly history
    for day in range(7, -1, -1):
        for hour in range(24):
            ts = now - timedelta(days=day, hours=(23 - hour) if day == 0 else 0)
            ts = datetime(ts.year, ts.month, ts.day, hour, 0, tzinfo=timezone.utc) if day else ts.replace(minute=0, second=0, microsecond=0)
            diurnal = 0.12 + 0.55 * math.exp(-((hour - 9.2) ** 2) / 4.5) + 0.42 * math.exp(-((hour - 13) ** 2) / 3.2) + 0.5 * math.exp(-((hour - 17.5) ** 2) / 5.5)
            pop = int(1800 + 3200 * diurnal + rng.randint(-80, 80))
            park = round(38 + 50 * diurnal + rng.uniform(-4, 4), 1)
            risk = round(12 + 40 * diurnal + rng.uniform(-4, 6), 1)
            db.add(
                CampusMetric(
                    population=pop,
                    crowd_peak_zone="Cafeteria" if 12 <= hour <= 14 else "Auditorium" if hour >= 16 else "Academic Block A",
                    parking_occupancy=min(park, 97),
                    traffic_index=40 + 120 * diurnal,
                    risk_score=min(risk, 78),
                    anomaly_count=1 if rng.random() > 0.85 else 0,
                    created_at=ts,
                )
            )
            for z in ZONE_DEFS:
                people = int(z["capacity"] * 0.22 * diurnal + rng.randint(0, 20))
                db.add(
                    CrowdRecord(
                        zone_code=z["code"],
                        people=people,
                        density="HIGH" if people > z["capacity"] * 0.7 else "MEDIUM" if people > z["capacity"] * 0.4 else "LOW",
                        growth_rate=rng.uniform(-6, 10),
                        direction="IN" if diurnal > 0.4 else "STABLE",
                        created_at=ts,
                    )
                )
            db.add(
                EnvironmentalData(
                    temperature_c=round(28 + 6 * math.sin((hour - 10) / 4) + rng.uniform(-0.6, 0.6), 1),
                    humidity=round(50 + rng.uniform(-8, 12), 1),
                    condition="Clear" if hour < 20 else "Partly Cloudy",
                    rain_mm=0,
                    aqi=int(60 + rng.randint(-8, 20)),
                    wind_kmh=round(6 + rng.uniform(-2, 5), 1),
                    created_at=ts,
                )
            )
            db.add(ResourceUsage(resource="electricity", value=round(3200 + 1800 * diurnal, 0), unit="kWh/day", baseline=4200, created_at=ts))
            db.add(ResourceUsage(resource="water", value=round(140 + 80 * diurnal, 1), unit="kL/day", baseline=190, created_at=ts))
            db.add(
                TrafficRecord(
                    route_code="main_gate",
                    volume=int(40 + 140 * diurnal),
                    congestion="HIGH" if diurnal > 0.7 else "MODERATE" if diurnal > 0.4 else "LOW",
                    direction="IN",
                    created_at=ts,
                )
            )
            for p in PARKING_DEFS:
                occ = int(p["total"] * (0.35 + 0.5 * diurnal) + rng.randint(-4, 4))
                db.add(
                    VehicleRecord(
                        zone_code=p["code"],
                        cars=occ if p["category"] != "TWO_WHEELER" else int(occ * 0.1),
                        bikes=occ if p["category"] == "TWO_WHEELER" else int(occ * 0.1),
                        other=0,
                        incoming=int(8 * diurnal),
                        outgoing=int(6 * diurnal),
                        created_at=ts,
                    )
                )

    db.add(
        Alert(
            alert_type="EVENT OVERCROWDING RISK",
            location="Auditorium",
            severity="LOW",
            reason="TECHNOVA 2026 is scheduled. Baseline watch opened.",
            prediction="Crowd may climb after 16:30.",
            recommended_action="Keep Plaza overflow on standby.",
            status="ACK",
        )
    )
    db.commit()
