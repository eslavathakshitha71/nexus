from datetime import datetime, timezone
from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text, create_engine
)
from sqlalchemy.orm import declarative_base, sessionmaker, relationship

from .config import DB_PATH

engine = create_engine(
    f"sqlite:///{DB_PATH}",
    connect_args={"check_same_thread": False},
    echo=False,
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def utcnow():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False, index=True)
    full_name = Column(String(120), nullable=False)
    email = Column(String(160), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(String(40), nullable=False, default="CAMPUS_ADMIN")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=utcnow)


class Building(Base):
    __tablename__ = "buildings"
    id = Column(Integer, primary_key=True)
    code = Column(String(40), unique=True, nullable=False)
    name = Column(String(120), nullable=False)
    kind = Column(String(40), nullable=False)
    capacity = Column(Integer, default=0)
    x = Column(Float, default=0)
    y = Column(Float, default=0)
    w = Column(Float, default=80)
    h = Column(Float, default=60)
    restricted = Column(Boolean, default=False)


class Zone(Base):
    __tablename__ = "zones"
    id = Column(Integer, primary_key=True)
    code = Column(String(40), unique=True, nullable=False)
    name = Column(String(120), nullable=False)
    kind = Column(String(40), nullable=False)
    building_id = Column(Integer, ForeignKey("buildings.id"), nullable=True)
    capacity = Column(Integer, default=0)
    x = Column(Float, default=0)
    y = Column(Float, default=0)
    w = Column(Float, default=80)
    h = Column(Float, default=60)


class Camera(Base):
    __tablename__ = "cameras"
    id = Column(Integer, primary_key=True)
    camera_id = Column(String(40), unique=True, nullable=False)
    name = Column(String(120), nullable=False)
    location = Column(String(160), nullable=False)
    zone_code = Column(String(40), nullable=False)
    status = Column(String(20), default="ONLINE")
    ai_status = Column(String(20), default="ACTIVE")
    fps = Column(Float, default=24.0)
    source_type = Column(String(20), default="DEMO")  # DEMO | UPLOAD | RTSP
    source_path = Column(String(400), nullable=True)
    last_update = Column(DateTime, default=utcnow)


class CameraEvent(Base):
    __tablename__ = "camera_events"
    id = Column(Integer, primary_key=True)
    camera_id = Column(String(40), nullable=False, index=True)
    event_type = Column(String(40), nullable=False)
    people_count = Column(Integer, default=0)
    vehicle_count = Column(Integer, default=0)
    density = Column(String(20), default="LOW")
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=utcnow, index=True)


class CrowdRecord(Base):
    __tablename__ = "crowd_records"
    id = Column(Integer, primary_key=True)
    zone_code = Column(String(40), nullable=False, index=True)
    people = Column(Integer, default=0)
    density = Column(String(20), default="LOW")
    growth_rate = Column(Float, default=0)
    direction = Column(String(40), default="STABLE")
    created_at = Column(DateTime, default=utcnow, index=True)


class VehicleRecord(Base):
    __tablename__ = "vehicle_records"
    id = Column(Integer, primary_key=True)
    zone_code = Column(String(40), nullable=False, index=True)
    cars = Column(Integer, default=0)
    bikes = Column(Integer, default=0)
    other = Column(Integer, default=0)
    incoming = Column(Integer, default=0)
    outgoing = Column(Integer, default=0)
    created_at = Column(DateTime, default=utcnow, index=True)


class ParkingZone(Base):
    __tablename__ = "parking_zones"
    id = Column(Integer, primary_key=True)
    code = Column(String(40), unique=True, nullable=False)
    name = Column(String(120), nullable=False)
    category = Column(String(40), nullable=False)
    total_slots = Column(Integer, default=0)
    occupied = Column(Integer, default=0)


class ParkingSlot(Base):
    __tablename__ = "parking_slots"
    id = Column(Integer, primary_key=True)
    zone_code = Column(String(40), nullable=False, index=True)
    slot_code = Column(String(40), nullable=False)
    occupied = Column(Boolean, default=False)
    vehicle_type = Column(String(20), default="CAR")


class CampusEvent(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True)
    name = Column(String(160), nullable=False)
    venue_code = Column(String(40), nullable=False)
    expected_attendance = Column(Integer, default=0)
    current_crowd = Column(Integer, default=0)
    capacity = Column(Integer, default=0)
    risk_level = Column(String(20), default="LOW")
    status = Column(String(20), default="SCHEDULED")
    starts_at = Column(DateTime, nullable=True)
    ends_at = Column(DateTime, nullable=True)
    description = Column(Text, default="")


class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    alert_type = Column(String(60), nullable=False)
    location = Column(String(120), nullable=False)
    severity = Column(String(20), nullable=False)
    reason = Column(Text, default="")
    prediction = Column(Text, default="")
    recommended_action = Column(Text, default="")
    status = Column(String(20), default="OPEN")
    created_at = Column(DateTime, default=utcnow, index=True)
    resolved_at = Column(DateTime, nullable=True)


class EnvironmentalData(Base):
    __tablename__ = "environmental_data"
    id = Column(Integer, primary_key=True)
    temperature_c = Column(Float, default=32.0)
    humidity = Column(Float, default=55.0)
    condition = Column(String(40), default="Clear")
    rain_mm = Column(Float, default=0.0)
    aqi = Column(Integer, default=72)
    wind_kmh = Column(Float, default=8.0)
    created_at = Column(DateTime, default=utcnow, index=True)


class ResourceUsage(Base):
    __tablename__ = "resource_usage"
    id = Column(Integer, primary_key=True)
    resource = Column(String(40), nullable=False, index=True)
    value = Column(Float, default=0)
    unit = Column(String(20), default="")
    baseline = Column(Float, default=0)
    created_at = Column(DateTime, default=utcnow, index=True)


class TrafficRecord(Base):
    __tablename__ = "traffic_records"
    id = Column(Integer, primary_key=True)
    route_code = Column(String(40), nullable=False, index=True)
    volume = Column(Integer, default=0)
    congestion = Column(String(20), default="LOW")
    direction = Column(String(40), default="BOTH")
    created_at = Column(DateTime, default=utcnow, index=True)


class Prediction(Base):
    __tablename__ = "predictions"
    id = Column(Integer, primary_key=True)
    kind = Column(String(40), nullable=False)
    target = Column(String(80), nullable=False)
    horizon_min = Column(Integer, default=30)
    current_value = Column(Float, default=0)
    predicted_value = Column(Float, default=0)
    confidence = Column(Float, default=0.8)
    recommendation = Column(Text, default="")
    created_at = Column(DateTime, default=utcnow, index=True)


class Simulation(Base):
    __tablename__ = "simulations"
    id = Column(Integer, primary_key=True)
    name = Column(String(160), nullable=False)
    scenario = Column(String(80), nullable=False)
    parameters = Column(Text, default="{}")
    result = Column(Text, default="{}")
    created_by = Column(String(80), default="admin")
    created_at = Column(DateTime, default=utcnow)


class CampusMetric(Base):
    __tablename__ = "campus_metrics"
    id = Column(Integer, primary_key=True)
    population = Column(Integer, default=0)
    crowd_peak_zone = Column(String(80), default="")
    parking_occupancy = Column(Float, default=0)
    traffic_index = Column(Float, default=0)
    risk_score = Column(Float, default=0)
    anomaly_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=utcnow, index=True)


class PrivacySetting(Base):
    __tablename__ = "privacy_settings"
    id = Column(Integer, primary_key=True)
    facial_recognition = Column(Boolean, default=False)
    identity_tracking = Column(Boolean, default=False)
    anonymous_analytics_only = Column(Boolean, default=True)
    data_retention_days = Column(Integer, default=30)
    store_raw_video = Column(Boolean, default=False)
    audit_logging = Column(Boolean, default=True)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    Base.metadata.create_all(bind=engine)
