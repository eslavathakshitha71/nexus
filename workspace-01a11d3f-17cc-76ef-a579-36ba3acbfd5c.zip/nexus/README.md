# NEXUS — AI Digital Twin for Campus Intelligence

**Understand the present. Simulate the future. Prevent the unexpected.**

NEXUS is a campus command center: a live digital twin of movement, crowd, parking, events, weather and resources — with anomaly detection, prediction, and a signature **What-If Simulator**. It is **not** an attendance, classroom, or facial-recognition system. Analytics are anonymous by default.

## Stack

- **Frontend:** React + TypeScript + Vite + Tailwind + Recharts
- **Backend:** Python FastAPI + SQLite + WebSockets + JWT
- **Vision:** OpenCV HOG person detection + anonymous vehicle blobs (upload a clip; demo cameras are simulated)
- **Intelligence:** rule + envelope anomaly detection, short-horizon forecasts, fused risk score, what-if projection

## Quick start

```bash
# backend
cd backend
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000

# frontend
cd frontend
npm install
npm run dev
```

Open the Vite app. API and WebSocket are proxied to port 8000.

## Demo operators

| Role | Username | Password |
|---|---|---|
| Super Admin | `superadmin` | `Nexus@2026` |
| Campus Admin | `campusadmin` | `Campus@2026` |
| Security Admin | `security` | `Secure@2026` |
| Event Admin | `eventadmin` | `Event@2026` |

## Hackathon walkthrough

1. Sign in as **campusadmin**.
2. Command view shows the live twin at nominal load.
3. Click **Run live demo** (or **Start TECHNOVA**).
4. Watch crowd climb, anomalies fire, parking and traffic forecasts move, risk score fuse.
5. Open **What-If** → *Main Gate Closed* → **Run simulation**.
6. Compare **current reality vs simulated future**.
7. Open **Explain** → generate the daily campus intelligence briefing.
8. Ask NEXUS: *How is the campus right now?* / *What could happen if Gate 1 is closed?*

## Privacy

Facial recognition and identity tracking are **off**. The twin counts people and vehicles, estimates density and flow, and never names a student.
